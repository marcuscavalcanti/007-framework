import json
import hashlib
import importlib
import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
CLI = ROOT / "scripts" / "framework_cli.py"
BIN = ROOT / "bin" / "007"


def reap(pidfile):
    try:
        os.kill(int(pidfile.read_text()), 9)
    except (FileNotFoundError, ValueError, ProcessLookupError):
        pass


class DashboardTests(unittest.TestCase):
    def module(self, name):
        sys.path.insert(0, str(SCRIPTS))
        try:
            return importlib.import_module(name)
        except ModuleNotFoundError:
            self.fail(f"missing production module: {name}")
        finally:
            sys.path.pop(0)

    def run_cli(self, *args, cwd=None):
        return subprocess.run(
            [sys.executable, str(CLI), *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
        )

    def test_init_registers_project_idempotently(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")

            first = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))
            second = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))

            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertEqual(second.returncode, 0, second.stderr)
            marker = json.loads((repo / ".007/project.json").read_text())
            projects = json.loads(registry.read_text())["projects"]
            self.assertEqual(marker["schema"], "007-framework/project/v1")
            self.assertEqual(marker["receipt_dir"], "receipts")
            self.assertEqual(len(projects), 1)
            self.assertEqual(projects[0]["project_id"], marker["project_id"])
            self.assertEqual(projects[0]["path"], str(repo.resolve()))
            self.assertTrue((repo / ".007/receipts").is_dir())
            self.assertEqual(
                subprocess.run(
                    ["git", "status", "--short"], cwd=repo,
                    capture_output=True, text=True, check=True,
                ).stdout,
                "",
            )

    def test_init_rejects_non_git_directory_without_writing(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "not-git")
            repo.mkdir()
            registry = Path(tmp, "state", "projects.json")

            result = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))

            self.assertEqual(result.returncode, 2)
            self.assertIn("not a Git repository", result.stderr)
            self.assertFalse((repo / ".007").exists())
            self.assertFalse(registry.exists())

    def test_init_rejects_malformed_registry_without_traceback(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            registry.parent.mkdir()
            registry.write_text(json.dumps({
                "schema": "007-framework/registry/v1",
                "projects": ["not-an-entry"],
            }))

            result = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))

            self.assertEqual(result.returncode, 2)
            self.assertIn("invalid registry", result.stderr)
            self.assertNotIn("Traceback", result.stderr)

    def test_route_receipts_cannot_escape_through_a_symlink(self):
        cli = self.module("framework_cli")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            state = repo / ".007"
            state.mkdir()
            (state / "project.json").write_text(json.dumps({
                "schema": "007-framework/project/v1",
                "project_id": "project-1",
                "name": "Example",
                "receipt_dir": "receipts",
            }))
            external = Path(tmp, "external")
            external.mkdir()
            (external / "foreign.receipt.json").write_text("{}")
            (state / "receipts").symlink_to(external, target_is_directory=True)

            with self.assertRaisesRegex(ValueError, "receipt_dir must stay inside .007"):
                cli.load_route_receipts(repo)

    def test_begin_creates_no_replace_task_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )

            first = self.run_cli("begin", "--repo", str(repo), "--task-id", "task-001")
            second = self.run_cli("begin", "--repo", str(repo), "--task-id", "task-001")

            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertIn("task-001", first.stdout)
            self.assertEqual(second.returncode, 2)
            self.assertIn("already exists", second.stderr)
            stored = json.loads((repo / ".007/tasks/task-001.task.json").read_text())
            self.assertEqual(stored["schema"], "007-framework/task-start/v1")
            self.assertEqual(stored["task_id"], "task-001")
            self.assertRegex(stored["started_at"], r"Z$")

    def test_begin_generates_safe_id_and_rejects_unsafe_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )

            generated = self.run_cli("begin", "--repo", str(repo))
            unsafe = self.run_cli("begin", "--repo", str(repo), "--task-id", "../escape")

            self.assertEqual(generated.returncode, 0, generated.stderr)
            task_id = generated.stdout.strip().split()[-1]
            self.assertRegex(task_id, r"^task-[A-Za-z0-9_-]+$")
            self.assertTrue((repo / f".007/tasks/{task_id}.task.json").is_file())
            self.assertEqual(unsafe.returncode, 2)
            self.assertIn("task_id", unsafe.stderr)
            self.assertFalse((repo / ".007/escape.task.json").exists())

    def test_receipt_task_class_is_open_only_to_supported_routing_classes(self):
        framework_cli = self.module("framework_cli")
        receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        receipt["task_class"] = "implement"

        self.assertIs(framework_cli.validate_receipt(receipt), receipt)
        receipt["task_class"] = "cheap-model-please"
        with self.assertRaisesRegex(ValueError, "task_class"):
            framework_cli.validate_receipt(receipt)

    def test_bound_authority_accepts_safe_events_and_summarizes_fences(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))
            begun = self.run_cli(
                "begin", "--repo", str(repo), "--task-id", "authority-safe",
                "--authority-file", str(authority),
            )
            self.assertEqual(begun.returncode, 0, begun.stderr)
            authority_hash = hashlib.sha256(authority.read_bytes()).hexdigest()
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt.update({
                "task_id": "authority-safe",
                "authority_sha256": authority_hash,
                "boundary_events": [
                    {"action": "test", "outcome": "executed"},
                    {"action": "deploy", "outcome": "blocked"},
                ],
            })
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps(receipt))

            recorded = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(recorded.returncode, 0, recorded.stderr)
            stored = json.loads((repo / ".007/receipts/authority-safe.receipt.json").read_text())
            self.assertEqual(stored["authority_sha256"], authority_hash)
            self.assertEqual(stored["authority_summary"], {
                "bound": True,
                "events": 2,
                "allowed_executions": 1,
                "protected_blocks": 1,
                "friction_blocks": 0,
                "unclassified_blocks": 0,
            })
            self.assertEqual(stored["authority_evidence"], "declared")

    def test_bound_authority_rejects_executed_denied_action(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))
            self.assertEqual(self.run_cli(
                "begin", "--repo", str(repo), "--task-id", "authority-violation",
                "--authority-file", str(authority),
            ).returncode, 0)
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt.update({
                "task_id": "authority-violation",
                "authority_sha256": hashlib.sha256(authority.read_bytes()).hexdigest(),
                "boundary_events": [{"action": "deploy", "outcome": "executed"}],
            })
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps(receipt))

            recorded = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(recorded.returncode, 2)
            self.assertIn("outside bound authority", recorded.stderr)
            self.assertFalse((repo / ".007/receipts/authority-violation.receipt.json").exists())

    def test_run_blocks_denied_action_before_subprocess(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "deny-1",
                "--receipt", "blocked.json", "--authority-file", str(authority),
                "--action", "deploy", "--", sys.executable, "-c",
                "from pathlib import Path; Path('sentinel').write_text('ran')",
            )

            self.assertEqual(result.returncode, 3, result.stderr)
            self.assertFalse((repo / "sentinel").exists())
            stored = json.loads((repo / ".007/receipts/deny-1.receipt.json").read_text())
            self.assertEqual(stored["authority_evidence"], "controlled")
            self.assertEqual(stored["authority_summary"]["protected_blocks"], 1)
            event = json.loads((repo / ".007/events/deny-1.event.json").read_text())
            self.assertEqual(event["outcome"], "blocked")
            self.assertIsNone(event["exit_code"])

    def test_run_records_allowed_action_as_controlled(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path('sentinel').write_text('ran')\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "allow-1",
                "--receipt", "allowed.json", "--authority-file", str(authority),
                "--action", "test", "--", sys.executable, str(adapter),
                str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue((repo / "sentinel").exists())
            stored = json.loads((repo / ".007/receipts/allow-1.receipt.json").read_text())
            self.assertEqual(stored["authority_evidence"], "controlled")
            self.assertEqual(stored["authority_summary"]["allowed_executions"], 1)
            event = json.loads((repo / ".007/events/allow-1.event.json").read_text())
            self.assertEqual(event["exit_code"], 0)

    def test_run_rejects_partial_authority_arguments_before_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))

            missing_action = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "partial-1",
                "--receipt", "partial-1.json", "--authority-file", str(authority),
                "--", sys.executable, "-c", "raise SystemExit(0)",
            )
            missing_authority = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "partial-2",
                "--receipt", "partial-2.json", "--action", "test",
                "--", sys.executable, "-c", "raise SystemExit(0)",
            )

            self.assertEqual(missing_action.returncode, 2)
            self.assertEqual(missing_authority.returncode, 2)
            self.assertFalse((repo / ".007/tasks/partial-1.task.json").exists())
            self.assertFalse((repo / ".007/tasks/partial-2.task.json").exists())

    def test_record_rejects_caller_supplied_controlled_provenance(self):
        cli = self.module("framework_cli")
        receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        receipt["authority_evidence"] = "controlled"

        with self.assertRaisesRegex(ValueError, "authority provenance"):
            cli.validate_receipt(receipt)

    def test_record_rejects_unpersisted_controller_event(self):
        cli = self.module("framework_cli")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(self.run_cli(
                "init", "--repo", str(repo), "--registry", str(registry),
            ).returncode, 0)
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1",
                "allow": ["test"],
                "deny": ["deploy"],
            }))
            task = cli.begin_task(repo, "forged-event", authority_file=authority)
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt.update({"task_id": "forged-event"})
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps(receipt))
            forged = {
                "schema": "007-framework/controller-event/v1",
                "task_id": "forged-event",
                "action": "test",
                "outcome": "executed",
                "authority_sha256": task["authority_sha256"],
                "observed_at": "2026-08-31T00:00:00Z",
                "exit_code": 0,
            }

            with self.assertRaisesRegex(ValueError, "persisted controller event"):
                cli.record_receipt(repo, source, controller_event=forged)

            self.assertFalse((repo / ".007/receipts/forged-event.receipt.json").exists())

    def test_record_requires_cost_and_writes_no_replace_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            self.assertEqual(
                self.run_cli("begin", "--repo", str(repo), "--task-id", "task-001").returncode,
                0,
            )
            receipt = {
                "schema": "007-framework/receipt/v1",
                "task_id": "task-001",
                "status": "accepted",
                "proof_required": "integrated",
                "proof_reached": "integrated",
                "checks": [{"command": "python3 -m unittest", "exit": 0}],
                "delta": {"files": 1, "added": 3, "deleted": 1, "dependencies": 0},
                "first_pass": "yes",
                "repair_rounds": 0,
                "corrective_lines": "pending",
                "escape_7d": "pending",
                "requested_provider": "openai",
                "requested_model": "gpt-requested",
                "requested_effort": "high",
                "served_provider": "openai",
                "served_model": "gpt-served",
                "served_effort": "xhigh",
                "tokens": 1200,
                "wall_s": 31,
                "cost_usd": 0.42,
                "cost_source": "provider-reported",
                "cost_status": "final",
                "uncertainty": "none",
            }
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps(receipt))

            first = self.run_cli("record", "--repo", str(repo), "--file", str(source))
            second = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertEqual(second.returncode, 2)
            stored = json.loads((repo / ".007/receipts/task-001.receipt.json").read_text())
            self.assertEqual(stored["cost_usd"], 0.42)
            self.assertEqual(stored["served_model"], "gpt-served")
            self.assertRegex(stored["completed_at"], r"Z$")

    def test_record_rejects_receipt_without_matching_task_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            source = Path(tmp, "receipt.json")
            source.write_text((ROOT / "examples/task.receipt.example.json").read_text())

            result = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(result.returncode, 2)
            self.assertIn("matching task start", result.stderr)
            self.assertFalse((repo / ".007/receipts/task-001.receipt.json").exists())

    def test_record_rejects_task_start_with_mismatched_task_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            self.assertEqual(
                self.run_cli("begin", "--repo", str(repo), "--task-id", "task-001").returncode,
                0,
            )
            task_path = repo / ".007/tasks/task-001.task.json"
            task = json.loads(task_path.read_text())
            task["task_id"] = "another-task"
            task_path.write_text(json.dumps(task))
            source = Path(tmp, "receipt.json")
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt["task_id"] = "task-001"
            source.write_text(json.dumps(receipt))

            result = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(result.returncode, 2)
            self.assertIn("task start task_id does not match receipt", result.stderr)
            self.assertFalse((repo / ".007/receipts/task-001.receipt.json").exists())

    def test_record_rejects_malformed_matching_task_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            self.assertEqual(
                self.run_cli("begin", "--repo", str(repo), "--task-id", "task-001").returncode,
                0,
            )
            (repo / ".007/tasks/task-001.task.json").write_text("not-json")
            source = Path(tmp, "receipt.json")
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt["task_id"] = "task-001"
            source.write_text(json.dumps(receipt))

            result = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(result.returncode, 2)
            self.assertNotIn("Traceback", result.stderr)
            self.assertFalse((repo / ".007/receipts/task-001.receipt.json").exists())

    def test_record_rejects_unaccounted_cost(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps({
                "schema": "007-framework/receipt/v1",
                "task_id": "task-no-cost",
                "status": "blocked",
                "cost_usd": "unmeasured",
                "cost_source": "unaccounted",
                "cost_status": "unaccounted",
            }))

            result = self.run_cli("record", "--repo", str(repo), "--file", str(source))

            self.assertEqual(result.returncode, 2)
            self.assertIn("cost_usd", result.stderr)
            self.assertFalse((repo / ".007/receipts/task-no-cost.receipt.json").exists())

    def test_record_rejects_non_finite_or_unaccounted_cost(self):
        cli = self.module("framework_cli")
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        with self.assertRaisesRegex(ValueError, "cost_usd"):
            cli.validate_receipt({**base, "cost_usd": float("nan")})
        with self.assertRaisesRegex(ValueError, "cost_source"):
            cli.validate_receipt({**base, "cost_source": "unaccounted"})
        with self.assertRaisesRegex(ValueError, "authority_summary"):
            cli.validate_receipt({**base, "authority_summary": {"bound": True}})

    def test_receipt_rejects_non_finite_tokens_and_wall_s(self):
        cli = self.module("framework_cli")
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        for key in ("tokens", "wall_s"):
            for value in (float("nan"), float("inf"), float("-inf")):
                with self.subTest(key=key, value=value):
                    with self.assertRaisesRegex(ValueError, key):
                        cli.validate_receipt({**base, key: value})
            for value in (0, 12.5, 10 ** 400, "unmeasured"):
                with self.subTest(key=key, value=value):
                    self.assertEqual(cli.validate_receipt({**base, key: value})[key], value)

    def test_record_accepts_documented_or_namespaced_cost_sources_only(self):
        cli = self.module("framework_cli")
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        for source in (
            "provider-reported", "rate-card-estimate", "subscription-allocated",
            "local-compute", "custom:team-chargeback",
        ):
            with self.subTest(source=source):
                self.assertEqual(cli.validate_receipt({**base, "cost_source": source})["cost_source"], source)
        with self.assertRaisesRegex(ValueError, "cost_source"):
            cli.validate_receipt({**base, "cost_source": "provider_reported"})

    def test_run_wraps_command_with_one_observed_task_lifecycle(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "value['uncertainty'] = os.environ['FRAMEWORK_007_REPO']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                "print('adapter-ok')\n"
            )

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "wrapped-001",
                "--receipt", "task.receipt.json", "--",
                sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("adapter-ok", result.stdout)
            self.assertTrue((repo / ".007/tasks/wrapped-001.task.json").is_file())
            stored = json.loads((repo / ".007/receipts/wrapped-001.receipt.json").read_text())
            self.assertEqual(stored["task_id"], "wrapped-001")
            self.assertEqual(stored["uncertainty"], str(repo.resolve()))

    def test_run_executor_kills_descendants_before_interpretation(self):
        for exit_code in (0, 7):
            with self.subTest(exit_code=exit_code), tempfile.TemporaryDirectory() as tmp:
                repo = Path(tmp, "repo")
                repo.mkdir()
                subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                self.assertEqual(self.run_cli(
                    "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                ).returncode, 0)
                adapter, pidfile = Path(tmp, "adapter.py"), Path(tmp, "child.pid")
                adapter.write_text(
                    "import json, os, subprocess, sys\nfrom pathlib import Path\n"
                    "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'], "
                    "stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
                    "Path(sys.argv[2]).write_text(str(child.pid))\n"
                    "value = json.loads(Path(sys.argv[1]).read_text())\n"
                    "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                    "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                    "raise SystemExit(int(sys.argv[3]))\n"
                )
                acceptance = Path(tmp, "acceptance.json")
                gate = (
                    "import os, sys\nfrom pathlib import Path\n"
                    "Path('acceptance.started').touch()\n"
                    "try: os.kill(int(Path(sys.argv[1]).read_text()), 0)\n"
                    "except ProcessLookupError: pass\n"
                    "else: raise SystemExit(9)\n"
                )
                acceptance.write_text(json.dumps({
                    "schema": "007-framework/acceptance/v1",
                    "commands": [[sys.executable, "-c", gate, str(pidfile)]],
                }))
                try:
                    result = self.run_cli(
                        "run", "--repo", str(repo), "--task-id", "executor-orphan",
                        "--receipt", "task.receipt.json", "--acceptance-file", str(acceptance),
                        "--", sys.executable, str(adapter),
                        str(ROOT / "examples/task.receipt.example.json"), str(pidfile), str(exit_code),
                    )
                    self.assertEqual(result.returncode, exit_code, result.stderr)
                    with self.assertRaises(ProcessLookupError, msg="executor child survived"):
                        os.kill(int(pidfile.read_text()), 0)
                    self.assertEqual((repo / "acceptance.started").exists(), exit_code == 0)
                    terminal = repo / ".007/receipts/executor-orphan.receipt.json"
                    self.assertEqual(terminal.exists(), exit_code == 0)
                    if exit_code == 0:
                        stored = json.loads(terminal.read_text())
                        self.assertEqual(stored["status"], "accepted")
                        self.assertEqual(stored["checks"][0]["exit"], 0)
                        self.assertEqual(stored["acceptance_evidence"], "controlled")
                finally:
                    reap(pidfile)  # Reap even on RED, before TemporaryDirectory removes the pidfile.

    def test_run_executor_remains_usable_off_main_thread(self):
        # Unconditional signal installation/restoration breaks the real helper call.
        cli = self.module("framework_cli")
        for exit_code in (0, 7):
            with self.subTest(exit_code=exit_code), tempfile.TemporaryDirectory() as tmp:
                repo = Path(tmp, "repo")
                repo.mkdir()
                subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                self.assertEqual(self.run_cli(
                    "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                ).returncode, 0)
                code = (
                    "import json, os, sys\nfrom pathlib import Path\n"
                    "value = json.loads(Path(sys.argv[1]).read_text())\n"
                    "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                    "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                    "raise SystemExit(int(sys.argv[2]))\n"
                )
                result, errors = [], []
                def invoke():
                    try:
                        result.append(cli.run_task(str(repo), "threaded", "task.receipt.json", [
                            sys.executable, "-c", code, str(ROOT / "examples/task.receipt.example.json"),
                            str(exit_code),
                        ]))
                    except Exception as error:
                        errors.append(error)
                worker = threading.Thread(target=invoke)
                worker.start()
                worker.join(timeout=10)
                self.assertFalse(worker.is_alive(), "run_task worker did not return")
                self.assertEqual(errors, [], repr(errors))
                self.assertEqual(result[0][0], exit_code)
                self.assertTrue((repo / ".007/tasks/threaded.task.json").is_file())
                self.assertEqual((repo / ".007/receipts/threaded.receipt.json").is_file(), exit_code == 0)

    def test_run_executor_shutdown_cleanup_keeps_first_signal_and_reports_non_gone(self):
        # A second scoped signal must not abort real group cleanup; missing diagnostics
        # must fail the two injected non-gone cases, not the gone positive control.
        for second, state, stderr_mode in (
            (True, "gone", "normal"), (False, "gone", "normal"),
            (False, "cleanup-child-unconfirmed", "normal"), (False, "cleanup-group-observable", "normal"),
            (False, "cleanup-child-unconfirmed", "pipe"), (False, "cleanup-group-observable", "closed"),
            (False, "cleanup-group-observable", "missing"), (False, "gone", "pipe"),
        ):
            with self.subTest(second=second, state=state, stderr_mode=stderr_mode), tempfile.TemporaryDirectory() as tmp:
                repo = Path(tmp, "repo")
                repo.mkdir()
                subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                self.assertEqual(self.run_cli(
                    "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                ).returncode, 0)
                adapter, pidfile, restored = (Path(tmp, name) for name in ("adapter.py", "pids.json", "restored.json"))
                adapter.write_text(
                    "import json, os, subprocess, sys, time\nfrom pathlib import Path\n"
                    "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(12)'])\n"
                    "value = json.loads(Path(sys.argv[1]).read_text())\n"
                    "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                    "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                    "Path(sys.argv[2]).write_text(json.dumps([os.getpid(), child.pid]))\n"
                    "time.sleep(12)\n"
                )
                authority, acceptance = Path(tmp, "authority.json"), Path(tmp, "acceptance.json")
                authority.write_text(json.dumps({
                    "schema": "007-framework/authority/v1", "allow": ["test"], "deny": ["deploy"],
                }))
                acceptance.write_text(json.dumps({
                    "schema": "007-framework/acceptance/v1",
                    "commands": [[sys.executable, "-c", "from pathlib import Path; Path('gate.ran').touch()"]],
                }))
                bootstrap = (
                    "import json, os, signal, sys\nfrom pathlib import Path\n"
                    "sys.path.insert(0, sys.argv[1])\nimport framework_cli as cli\n"
                    "mode = os.environ['TEST_007_STDERR_MODE']\n"
                    "if mode == 'pipe':\n"
                    "    reader, writer = os.pipe()\n    os.close(reader)\n"
                    "    sys.stderr = os.fdopen(writer, 'w', buffering=1)\n"
                    "elif mode == 'closed':\n"
                    "    sys.stderr = open(os.devnull, 'w')\n    sys.stderr.close()\n"
                    "elif mode == 'missing': sys.stderr = None\n"
                    "signals = (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT)\n"
                    "observed = []\n"
                    "def caller(signum, frame): observed.append(signum)\n"
                    "for sig in signals: signal.signal(sig, caller)\n"
                    "real_cleanup = cli.kill_process_group\n"
                    "def injected(process, wait_s=2.0):\n"
                    "    if sys.argv[2] == 'True':\n"
                    "        for sig in signals: signal.raise_signal(sig)\n"
                    "    actual = real_cleanup(process, wait_s)\n"
                    "    return actual if sys.argv[3] == 'gone' else sys.argv[3]\n"
                    "cli.kill_process_group = injected\n"
                    "try: cli.main(sys.argv[5:])\n"
                    "except SystemExit as error:\n"
                    "    intact = all(signal.getsignal(sig) is caller for sig in signals)\n"
                    "    if intact:\n"
                    "        for sig in signals: signal.raise_signal(sig)\n"
                    "    Path(sys.argv[4]).write_text(json.dumps({'intact': intact, 'observed': observed}))\n"
                    "    raise\n"
                )
                controller = subprocess.Popen(
                    [sys.executable, "-c", bootstrap, str(SCRIPTS), str(second), state, str(restored),
                     "run", "--repo", str(repo), "--task-id", "shutdown",
                     "--receipt", "task.receipt.json", "--authority-file", str(authority),
                     "--action", "test", "--acceptance-file", str(acceptance), "--",
                     sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json"), str(pidfile)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True,
                    env={**os.environ, "TEST_007_STDERR_MODE": stderr_mode},
                )
                pids = []
                try:
                    deadline = time.monotonic() + 5
                    while time.monotonic() < deadline:
                        try:
                            pids = json.loads(pidfile.read_text())
                            break
                        except (FileNotFoundError, json.JSONDecodeError):
                            time.sleep(0.01)
                    self.assertEqual(len(pids), 2, "executor readiness missing")
                    os.kill(controller.pid, signal.SIGTERM)
                    controller.wait(timeout=8)
                    self.assertEqual(controller.returncode, 143)
                    for pid in pids:
                        with self.assertRaises(ProcessLookupError, msg="executor survived shutdown cleanup"):
                            os.kill(pid, 0)
                    stdout, stderr = controller.communicate(timeout=8)
                    self.assertEqual(stdout, "", "shutdown diagnostic leaked to stdout")
                    self.assertEqual(json.loads(restored.read_text()), {
                        "intact": True, "observed": [signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT],
                    })
                    if state == "gone" or stderr_mode != "normal":
                        self.assertEqual(stderr, "")
                    else:
                        self.assertIn(state, stderr)
                        self.assertIn(str(pids[0]), stderr)
                    self.assertFalse((repo / "gate.ran").exists())
                    self.assertFalse((repo / ".007/events/shutdown.event.json").exists())
                    self.assertFalse((repo / ".007/receipts/shutdown.receipt.json").exists())
                    self.assertTrue((repo / ".007/tasks/shutdown.task.json").is_file())
                finally:
                    for group in pids[:1] + [controller.pid]:
                        try:
                            os.killpg(group, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    controller.communicate(timeout=5)
                    for pid in pids:
                        try:
                            os.kill(pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass

    def test_run_executor_signal_shutdown_kills_group_without_terminal_progression(self):
        # Removing the scoped shutdown handlers must leave the real executor alive.
        for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT, signal.SIGINT):
            with self.subTest(signal=sig), tempfile.TemporaryDirectory() as tmp:
                repo = Path(tmp, "repo")
                repo.mkdir()
                subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                self.assertEqual(self.run_cli(
                    "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                ).returncode, 0)
                adapter, pidfile = Path(tmp, "adapter.py"), Path(tmp, "pids.json")
                adapter.write_text(
                    "import json, os, subprocess, sys, time\nfrom pathlib import Path\n"
                    "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(12)'])\n"
                    "value = json.loads(Path(sys.argv[1]).read_text())\n"
                    "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                    "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                    "Path(sys.argv[2]).write_text(json.dumps([os.getpid(), child.pid]))\n"
                    "time.sleep(12)\n"
                )
                authority, acceptance = Path(tmp, "authority.json"), Path(tmp, "acceptance.json")
                authority.write_text(json.dumps({
                    "schema": "007-framework/authority/v1", "allow": ["test"], "deny": ["deploy"],
                }))
                acceptance.write_text(json.dumps({
                    "schema": "007-framework/acceptance/v1",
                    "commands": [[sys.executable, "-c", "from pathlib import Path; Path('gate.ran').touch()"]],
                }))
                bootstrap = (
                    "import resource, signal, sys\nresource.setrlimit(resource.RLIMIT_CORE, (0, 0))\n"
                    "for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT): signal.signal(sig, signal.SIG_DFL)\n"
                    "signal.signal(signal.SIGINT, signal.default_int_handler)\n"
                    "sys.path.insert(0, sys.argv[1])\nimport framework_cli as cli\n"
                    "raise SystemExit(cli.main(sys.argv[2:]))\n"
                )
                controller = subprocess.Popen(
                    [sys.executable, "-c", bootstrap, str(SCRIPTS),
                     "run", "--repo", str(repo), "--task-id", "shutdown",
                     "--receipt", "task.receipt.json", "--authority-file", str(authority),
                     "--action", "test", "--acceptance-file", str(acceptance), "--",
                     sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json"), str(pidfile)],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                )
                pids = []
                try:
                    deadline = time.monotonic() + 5
                    while time.monotonic() < deadline:
                        try:
                            pids = json.loads(pidfile.read_text())
                            break
                        except (FileNotFoundError, json.JSONDecodeError):
                            time.sleep(0.01)
                    self.assertEqual(len(pids), 2, "executor readiness missing")
                    self.assertEqual(os.getpgid(pids[0]), pids[0])
                    if sig == signal.SIGINT:
                        os.kill(controller.pid, sig)  # Exercise KeyboardInterrupt in wait(), not a normal exit.
                    else:
                        os.killpg(controller.pid, sig)
                    controller.wait(timeout=8)
                    for pid in pids:
                        with self.assertRaises(ProcessLookupError, msg=f"executor group member {pid} survived {sig}"):
                            os.kill(pid, 0)
                    self.assertNotEqual(controller.returncode, 0)
                    if sig != signal.SIGINT:
                        self.assertEqual(controller.returncode, 128 + sig)
                    self.assertTrue((repo / ".007/tasks/shutdown.task.json").is_file())
                    self.assertTrue((repo / "task.receipt.json").is_file())  # Raw adapter output is not persistence.
                    self.assertFalse((repo / "gate.ran").exists())
                    self.assertFalse((repo / ".007/events/shutdown.event.json").exists())
                    self.assertFalse((repo / ".007/receipts/shutdown.receipt.json").exists())
                finally:
                    for group in (pids[:1] + [controller.pid]):
                        try:
                            os.killpg(group, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    controller.wait(timeout=5)
                    for pid in pids:
                        try:
                            os.kill(pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass

    def test_run_executor_preserves_inherited_ignored_shutdown_signals(self):
        # Unconditional handler installation must fail this ignored-signal control.
        for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT):
            for exit_code in (0, 7):
                with self.subTest(signal=sig, exit_code=exit_code), tempfile.TemporaryDirectory() as tmp:
                    repo = Path(tmp, "repo")
                    repo.mkdir()
                    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                    self.assertEqual(self.run_cli(
                        "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                    ).returncode, 0)
                    adapter, pidfile, release = (Path(tmp, name) for name in ("adapter.py", "pid", "release"))
                    adapter.write_text(
                        "import json, os, sys, time\nfrom pathlib import Path\n"
                        "Path(sys.argv[2]).write_text(str(os.getpid()))\n"
                        "deadline = time.monotonic() + 12\n"
                        "while not Path(sys.argv[3]).exists():\n"
                        "    if time.monotonic() >= deadline: raise SystemExit(9)\n"
                        "    time.sleep(0.01)\n"
                        "value = json.loads(Path(sys.argv[1]).read_text())\n"
                        "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                        "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                        "raise SystemExit(int(sys.argv[4]))\n"
                    )
                    bootstrap = (
                        "import signal, sys\nsignal.signal(int(sys.argv[2]), signal.SIG_IGN)\n"
                        "sys.path.insert(0, sys.argv[1])\nimport framework_cli as cli\n"
                        "raise SystemExit(cli.main(sys.argv[3:]))\n"
                    )
                    controller = subprocess.Popen(
                        [sys.executable, "-c", bootstrap, str(SCRIPTS), str(int(sig)),
                         "run", "--repo", str(repo), "--task-id", "ignored",
                         "--receipt", "task.receipt.json", "--", sys.executable, str(adapter),
                         str(ROOT / "examples/task.receipt.example.json"), str(pidfile), str(release), str(exit_code)],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
                    )
                    executor_pid = None
                    try:
                        deadline = time.monotonic() + 5
                        while time.monotonic() < deadline:
                            try:
                                executor_pid = int(pidfile.read_text())
                                break
                            except (FileNotFoundError, ValueError):
                                time.sleep(0.01)
                        self.assertIsNotNone(executor_pid, "executor readiness missing")
                        self.assertEqual(os.getpgid(executor_pid), executor_pid)
                        os.kill(controller.pid, sig)
                        with self.assertRaises(subprocess.TimeoutExpired, msg="ignored signal interrupted executor"):
                            controller.wait(timeout=0.1)
                        release.touch()
                        controller.wait(timeout=8)
                        self.assertEqual(controller.returncode, exit_code)
                        with self.assertRaises(ProcessLookupError):
                            os.kill(executor_pid, 0)
                        self.assertTrue((repo / ".007/tasks/ignored.task.json").is_file())
                        terminal = repo / ".007/receipts/ignored.receipt.json"
                        self.assertEqual(terminal.is_file(), exit_code == 0)
                        if exit_code == 0:
                            self.assertEqual(json.loads(terminal.read_text())["status"], "accepted")
                    finally:
                        for group in ([executor_pid] if executor_pid else []) + [controller.pid]:
                            try:
                                os.killpg(group, signal.SIGKILL)
                            except ProcessLookupError:
                                pass
                        controller.wait(timeout=5)

    def test_run_executor_restores_callers_signal_handlers_on_exit_or_exception(self):
        # A leaked controller handler would swallow the caller's next real signal.
        cli = self.module("framework_cli")
        signals = (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT)
        saved = {sig: signal.getsignal(sig) for sig in (*signals, signal.SIGINT)}
        observed = []
        def caller(signum, frame):
            observed.append(signum)
        real_cleanup = cli.kill_process_group
        real_getsignal = signal.getsignal
        def cleanup_error(process, wait_s=2.0):
            real_cleanup(process, wait_s)
            raise RuntimeError("cleanup probe")
        try:
            for sig in signals:
                signal.signal(sig, caller)
            for outcome in (0, 7, "spawn-error", "cleanup-error", "unknown-handler"):
                with self.subTest(outcome=outcome), tempfile.TemporaryDirectory() as tmp:
                    repo = Path(tmp, "repo")
                    repo.mkdir()
                    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
                    self.assertEqual(self.run_cli(
                        "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
                    ).returncode, 0)
                    code = (
                        "import json, os, sys\nfrom pathlib import Path\n"
                        "value = json.loads(Path(sys.argv[1]).read_text())\n"
                        "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                        "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                        "raise SystemExit(int(sys.argv[2]))\n"
                    )
                    command = [sys.executable, "-c", code, str(ROOT / "examples/task.receipt.example.json"),
                               str(outcome if isinstance(outcome, int) else 0)]
                    if outcome == "spawn-error":
                        with self.assertRaises(FileNotFoundError):
                            cli.run_task(str(repo), "restore", "task.receipt.json", [str(Path(tmp, "missing"))])
                    elif outcome == "cleanup-error":
                        with mock.patch.object(cli, "kill_process_group", cleanup_error), \
                                self.assertRaisesRegex(RuntimeError, "cleanup probe"):
                            cli.run_task(str(repo), "restore", "task.receipt.json", command)
                    elif outcome == "unknown-handler":
                        with mock.patch.object(signal, "getsignal", side_effect=lambda sig:
                                               None if sig == signal.SIGTERM else real_getsignal(sig)):
                            try:
                                status, _ = cli.run_task(str(repo), "restore", "task.receipt.json", command)
                            except TypeError as error:
                                self.fail(f"unknown caller handler was replaced: {error}")
                            self.assertEqual(status, 0)
                    else:
                        self.assertEqual(cli.run_task(str(repo), "restore", "task.receipt.json", command)[0], outcome)
                    for sig in signals:
                        self.assertIs(signal.getsignal(sig), caller)
                    self.assertIs(signal.getsignal(signal.SIGINT), saved[signal.SIGINT])
                    observed.clear()
                    for sig in signals:
                        signal.raise_signal(sig)
                    self.assertEqual(observed, list(signals))
        finally:
            for sig, handler in saved.items():
                signal.signal(sig, handler)

    def test_run_executor_cleanup_failure_leaves_start_open(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            self.assertEqual(self.run_cli(
                "init", "--repo", str(repo), "--registry", str(Path(tmp, "projects.json")),
            ).returncode, 0)
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\nfrom pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
                "raise SystemExit(int(sys.argv[2]))\n"
            )
            authority = Path(tmp, "authority.json")
            authority.write_text(json.dumps({
                "schema": "007-framework/authority/v1", "allow": ["test"], "deny": ["deploy"],
            }))
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1",
                "commands": [[sys.executable, "-c", "from pathlib import Path; Path('gate.ran').touch()"]],
            }))
            # Run the public CLI entrypoint in a subprocess; inject only the reported
            # cleanup state after real cleanup, never replace execution or acceptance.
            bootstrap = (
                "import sys\nsys.path.insert(0, sys.argv[1])\nimport framework_cli as cli\n"
                "real_cleanup = cli.kill_process_group\n"
                "def injected(process, wait_s=2.0):\n"
                "    actual = real_cleanup(process, wait_s)\n"
                "    return actual if sys.argv[2] == 'gone' else sys.argv[2]\n"
                "cli.kill_process_group = injected\nraise SystemExit(cli.main(sys.argv[3:]))\n"
            )
            for state in ("gone", "cleanup-child-unconfirmed", "cleanup-group-observable"):
                for exit_code in (0, 7):
                    with self.subTest(state=state, exit_code=exit_code):
                        task_id = f"executor-{state}-{exit_code}"
                        accepted = state == "gone" and exit_code == 0
                        try:
                            result = subprocess.run(
                                [sys.executable, "-c", bootstrap, str(SCRIPTS), state,
                                 "run", "--repo", str(repo), "--task-id", task_id,
                                 "--receipt", "task.receipt.json", "--authority-file", str(authority),
                                 "--action", "test", "--acceptance-file", str(acceptance), "--",
                                 sys.executable, str(adapter),
                                 str(ROOT / "examples/task.receipt.example.json"), str(exit_code)],
                                capture_output=True, text=True, timeout=30,
                            )
                            self.assertEqual(result.returncode, exit_code if state == "gone" else 2, result.stderr)
                            task = json.loads((repo / f".007/tasks/{task_id}.task.json").read_text())
                            event = json.loads((repo / f".007/events/{task_id}.event.json").read_text())
                            self.assertEqual(event["task_id"], task_id)
                            self.assertEqual(event["action"], "test")
                            self.assertEqual(event["outcome"], "executed")
                            self.assertEqual(event["exit_code"], exit_code)
                            self.assertEqual(event["authority_sha256"], task["authority_sha256"])
                            terminal = repo / f".007/receipts/{task_id}.receipt.json"
                            self.assertEqual(terminal.exists(), accepted)
                            self.assertEqual((repo / "gate.ran").exists(), accepted)
                            if state != "gone":
                                self.assertIn(f"executor cleanup incomplete: {state}", result.stderr)
                            if accepted:
                                stored = json.loads(terminal.read_text())
                                self.assertEqual(stored["status"], "accepted")
                                self.assertEqual(stored["authority_evidence"], "controlled")
                                self.assertEqual(stored["acceptance_evidence"], "controlled")
                        finally:
                            (repo / "task.receipt.json").unlink(missing_ok=True)
                            (repo / "gate.ran").unlink(missing_ok=True)

    def test_run_replaces_claimed_checks_with_controller_observed_acceptance(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "value['checks'] = [{'command': 'agent-claimed-pass', 'exit': 0}]\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1",
                "commands": [[sys.executable, "-c", "print('gate-ok')"]],
            }))

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "controlled-gate-pass",
                "--receipt", "task.receipt.json", "--acceptance-file", str(acceptance),
                "--", sys.executable, str(adapter),
                str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            stored = json.loads((repo / ".007/receipts/controlled-gate-pass.receipt.json").read_text())
            task = json.loads((repo / ".007/tasks/controlled-gate-pass.task.json").read_text())
            self.assertEqual(stored["acceptance_evidence"], "controlled")
            self.assertEqual(stored["acceptance_sha256"], hashlib.sha256(acceptance.read_bytes()).hexdigest())
            self.assertEqual(stored["checks"][0]["command"], [sys.executable, "-c", "print('gate-ok')"])
            self.assertEqual(stored["checks"][0]["exit"], 0)
            self.assertRegex(stored["checks"][0]["stdout_sha256"], r"^[0-9a-f]{64}$")
            self.assertRegex(stored["checks"][0]["stderr_sha256"], r"^[0-9a-f]{64}$")
            self.assertGreaterEqual(stored["checks"][0]["duration_ms"], 0)
            self.assertEqual(task["acceptance_sha256"], stored["acceptance_sha256"])
            self.assertEqual(task["acceptance"]["commands"], [[sys.executable, "-c", "print('gate-ok')"]])

    def test_run_persists_blocked_receipt_when_controller_acceptance_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1",
                "commands": [[sys.executable, "-c", "raise SystemExit(5)"]],
            }))

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "controlled-gate-fail",
                "--receipt", "task.receipt.json", "--acceptance-file", str(acceptance),
                "--", sys.executable, str(adapter),
                str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 4, result.stderr)
            stored = json.loads((repo / ".007/receipts/controlled-gate-fail.receipt.json").read_text())
            self.assertEqual(stored["status"], "blocked")
            self.assertEqual(stored["proof_reached"], "acceptance-failed")
            self.assertEqual(stored["checks"][0]["exit"], 5)
            self.assertEqual(stored["acceptance_summary"], {"passed": 0, "failed": 1})

    def test_run_acceptance_timeout_kills_descendants_and_blocks(self):
        # public CLI path: a timed-out hard gate blocks the receipt and leaves no descendant behind
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )
            pidfile = Path(tmp, "grandchild.pid")
            spawner = (
                "import subprocess, sys, time; "
                "subprocess.Popen([sys.executable, '-c', "
                "'import os, sys, time; open(sys.argv[1], \"w\").write(str(os.getpid())); time.sleep(60)', sys.argv[1]]); "
                "time.sleep(60)"
            )
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1", "timeout_s": 1,
                "commands": [[sys.executable, "-c", spawner, str(pidfile)]],
            }))

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "controlled-gate-timeout",
                "--receipt", "task.receipt.json", "--acceptance-file", str(acceptance),
                "--", sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 4, result.stderr)
            self.addCleanup(reap, pidfile)
            stored = json.loads((repo / ".007/receipts/controlled-gate-timeout.receipt.json").read_text())
            self.assertEqual(stored["status"], "blocked")
            self.assertTrue(stored["checks"][0]["timed_out"])
            self.assertEqual(stored["checks"][0]["exit"], 124)
            self.assertLess(stored["checks"][0]["duration_ms"], 20000)
            pid = int(pidfile.read_text())
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.1)
            else:
                self.fail("grandchild survived the acceptance timeout")

    def test_run_acceptance_kills_descendants_after_normal_exit(self):
        # public CLI path: a passing hard gate that spawned a background process leaves nothing behind
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )
            pidfile = Path(tmp, "grandchild.pid")
            spawner = (
                "import subprocess, sys; "
                "child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'], "
                "stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); "
                "open(sys.argv[1], 'w').write(str(child.pid)); sys.exit(0)"
            )
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1", "timeout_s": 10,
                "commands": [[sys.executable, "-c", spawner, str(pidfile)]],
            }))

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "controlled-gate-orphan",
                "--receipt", "task.receipt.json", "--acceptance-file", str(acceptance),
                "--", sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json"),
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.addCleanup(reap, pidfile)
            stored = json.loads((repo / ".007/receipts/controlled-gate-orphan.receipt.json").read_text())
            self.assertEqual(stored["status"], "accepted")
            self.assertEqual(stored["checks"][0]["exit"], 0)
            self.assertFalse(stored["checks"][0]["timed_out"])
            pid = int(pidfile.read_text())
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    break
                time.sleep(0.1)
            else:
                self.fail("grandchild survived a passing acceptance command")

    def test_run_acceptance_cleanup_failure_exits_without_terminal_receipt(self):
        # cleanup boundary substituted: no receipt, start left open, explicit error (CLI maps ValueError to exit 2)
        cli = self.module("framework_cli")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )
            adapter = Path(tmp, "adapter.py")
            adapter.write_text(
                "import json, os, sys\n"
                "from pathlib import Path\n"
                "value = json.loads(Path(sys.argv[1]).read_text())\n"
                "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
                "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
            )
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1",
                "commands": [[sys.executable, "-c", "print('gate-ok')"]],
            }))
            real_cleanup = cli.kill_process_group
            for state in ("cleanup-child-unconfirmed", "cleanup-group-observable"):
                with self.subTest(state=state):
                    task_id = f"cleanup-{state}"
                    # the real kill still runs; only the reported state is substituted
                    def stub(process, wait_s=2.0):
                        actual = real_cleanup(process, wait_s)
                        return state if process.args == [sys.executable, "-c", "print('gate-ok')"] else actual
                    with mock.patch.object(cli, "kill_process_group", stub):
                        with self.assertRaisesRegex(
                            ValueError, f"acceptance cleanup incomplete: {state} for process group .*command exit 0, timed_out False",
                        ):
                            cli.run_task(
                                str(repo), task_id, "task.receipt.json",
                                [sys.executable, str(adapter), str(ROOT / "examples/task.receipt.example.json")],
                                acceptance_file=str(acceptance),
                            )
                    self.assertTrue((repo / f".007/tasks/{task_id}.task.json").is_file())
                    self.assertFalse((repo / f".007/receipts/{task_id}.receipt.json").exists())
                    (repo / "task.receipt.json").unlink()

    def test_run_leaves_start_open_when_command_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "wrapped-failed",
                "--receipt", "task.receipt.json", "--",
                sys.executable, "-c", "raise SystemExit(7)",
            )

            self.assertEqual(result.returncode, 7, result.stderr)
            self.assertTrue((repo / ".007/tasks/wrapped-failed.task.json").is_file())
            self.assertFalse((repo / ".007/receipts/wrapped-failed.receipt.json").exists())

    def test_run_rejects_success_without_terminal_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )

            result = self.run_cli(
                "run", "--repo", str(repo), "--task-id", "wrapped-missing",
                "--receipt", "task.receipt.json", "--", sys.executable, "-c", "pass",
            )

            self.assertEqual(result.returncode, 2)
            self.assertIn("did not produce terminal receipt", result.stderr)
            self.assertTrue((repo / ".007/tasks/wrapped-missing.task.json").is_file())
            self.assertFalse((repo / ".007/receipts/wrapped-missing.receipt.json").exists())

    def test_unregister_removes_only_the_registry_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            self.assertEqual(
                self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode,
                0,
            )

            result = self.run_cli(
                "unregister", "--project", str(repo), "--registry", str(registry)
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(registry.read_text())["projects"], [])
            self.assertTrue((repo / ".007/project.json").exists())

    def test_bin_entrypoint_exposes_help(self):
        result = subprocess.run(
            [str(BIN), "--help"], capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("007 Framework", result.stdout)

    def test_aggregate_reconciles_raw_project_totals(self):
        dashboard = self.module("dashboard")
        projects = [
            {"available": True, "metrics": {
                "tasks": 2, "accepted": 1, "blocked": 1, "no_op": 0,
                "first_pass_yes": 1, "first_pass_known": 1,
                "repair_rounds_sum": 0, "repair_rounds_known_tasks": 1,
                "tokens_known_sum": 100, "tokens_known_tasks": 1,
                "wall_s_known_sum": 20, "wall_s_known_tasks": 1,
                "cost_usd_known_sum": 0.2, "cost_usd_known_tasks": 1,
                "escape_7d_yes": 0, "escape_7d_known": 1,
                "telemetry_known": 4, "telemetry_possible": 8,
                "delta_files": 2, "delta_added": 10, "delta_deleted": 3,
            }, "touch": {
                "7": {"agent_lines_added": 10, "surviving_lines": 9, "rate": 10.0},
                "30": {"agent_lines_added": 10, "surviving_lines": 8, "rate": 20.0},
            }},
            {"available": True, "metrics": {
                "tasks": 3, "accepted": 2, "blocked": 0, "no_op": 1,
                "first_pass_yes": 1, "first_pass_known": 2,
                "repair_rounds_sum": 2, "repair_rounds_known_tasks": 2,
                "tokens_known_sum": 0, "tokens_known_tasks": 0,
                "wall_s_known_sum": 30, "wall_s_known_tasks": 2,
                "cost_usd_known_sum": 0, "cost_usd_known_tasks": 0,
                "escape_7d_yes": 1, "escape_7d_known": 2,
                "telemetry_known": 3, "telemetry_possible": 12,
                "delta_files": 4, "delta_added": 20, "delta_deleted": 5,
            }, "touch": {
                "7": {"agent_lines_added": 20, "surviving_lines": 20, "rate": 0.0},
                "30": {"agent_lines_added": 20, "surviving_lines": 10, "rate": 50.0},
            }},
        ]

        result = dashboard.aggregate_projects(projects)

        self.assertEqual(result["tasks"], 5)
        self.assertEqual(result["accepted"], 3)
        self.assertEqual(result["first_pass_rate"], 2 / 3)
        self.assertEqual(result["tokens_known_sum"], 100)
        self.assertEqual(result["tokens_missing_tasks"], 4)
        self.assertEqual(result["repair_rounds_mean"], 2 / 3)
        self.assertEqual(result["escape_7d_rate"], 1 / 3)
        self.assertEqual(result["touch"]["30"]["rate"], 40.0)
        self.assertEqual(result["delta_added"], 30)

    def test_lifecycle_reconciles_starts_and_reliable_cost(self):
        dashboard = self.module("dashboard")
        starts = [
            {"task_id": "accepted-stable"},
            {"task_id": "accepted-escaped"},
            {"task_id": "still-running"},
        ]
        receipts = [
            {
                "task_id": "accepted-stable", "status": "accepted",
                "first_pass": "yes", "escape_7d": "no",
                "cost_usd": 0.4, "cost_source": "provider-reported", "cost_status": "final",
            },
            {
                "task_id": "accepted-escaped", "status": "accepted",
                "first_pass": "yes", "escape_7d": "yes",
                "cost_usd": 0.5, "cost_source": "provider-reported", "cost_status": "final",
            },
            {
                "task_id": "legacy-blocked", "status": "blocked",
                "first_pass": "no", "escape_7d": "no",
                "cost_usd": 0.1, "cost_source": "provider-reported", "cost_status": "final",
            },
        ]

        result = dashboard.metrics_from_observations(receipts, starts)

        self.assertEqual(result["started_tasks"], 3)
        self.assertEqual(result["matched_terminal_tasks"], 2)
        self.assertEqual(result["active_tasks"], 1)
        self.assertEqual(result["unstarted_terminal_tasks"], 1)
        self.assertEqual(result["observation_coverage"], 2 / 3)
        self.assertEqual(result["accepted_first_pass_yes"], 2)
        self.assertEqual(result["reliable_first_pass_yes"], 1)
        self.assertEqual(result["reliable_first_pass_known"], 2)
        self.assertEqual(result["reliable_first_pass_rate"], 0.5)
        self.assertEqual(result["cost_usd_per_reliable"], 1.0)

    def test_roi_uses_all_attempt_cost_and_time_per_reliable_outcome(self):
        dashboard = self.module("dashboard")
        starts = [{"task_id": task_id} for task_id in ("stable-a", "stable-b", "failed")]
        receipts = [
            {
                "task_id": "stable-a", "status": "accepted", "first_pass": "yes",
                "escape_7d": "no", "cost_usd": 0.2,
                "cost_source": "provider-reported", "cost_status": "final", "wall_s": 10,
            },
            {
                "task_id": "stable-b", "status": "accepted", "first_pass": "yes",
                "escape_7d": "no", "cost_usd": 0.3,
                "cost_source": "provider-reported", "cost_status": "final", "wall_s": 20,
            },
            {
                "task_id": "failed", "status": "blocked", "first_pass": "no",
                "escape_7d": "no", "cost_usd": 0.5,
                "cost_source": "provider-reported", "cost_status": "final", "wall_s": 30,
            },
        ]

        result = dashboard.metrics_from_observations(receipts, starts)

        self.assertEqual(result["cost_usd_per_reliable"], 0.5)
        self.assertEqual(result["reliable_outcomes_per_usd"], 2.0)
        self.assertEqual(result["wall_s_per_reliable"], 30.0)

    def test_roi_stays_unknown_when_cost_or_time_is_incomplete(self):
        dashboard = self.module("dashboard")
        starts = [{"task_id": "stable"}, {"task_id": "missing"}]
        receipts = [
            {
                "task_id": "stable", "status": "accepted", "first_pass": "yes",
                "escape_7d": "no", "cost_usd": 0.2,
                "cost_source": "provider-reported", "cost_status": "final", "wall_s": 10,
            },
            {
                "task_id": "missing", "status": "blocked", "first_pass": "no",
                "escape_7d": "no", "wall_s": "unmeasured",
            },
        ]

        result = dashboard.metrics_from_observations(receipts, starts)

        self.assertIsNone(result["reliable_outcomes_per_usd"])
        self.assertIsNone(result["wall_s_per_reliable"])

    def test_lifecycle_is_unknown_without_starts_or_matured_outcomes(self):
        dashboard = self.module("dashboard")
        receipts = [{
            "task_id": "legacy", "status": "accepted", "first_pass": "yes",
            "escape_7d": "pending", "cost_usd": 0.2,
            "cost_source": "provider-reported", "cost_status": "final",
        }]

        result = dashboard.metrics_from_observations(receipts, [])

        self.assertIsNone(result["observation_coverage"])
        self.assertIsNone(result["reliable_first_pass_rate"])
        self.assertIsNone(result["cost_usd_per_reliable"])
        self.assertEqual(result["unstarted_terminal_tasks"], 1)

    def test_evidence_state_names_inactive_instrumentation(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_observations([], [])
        touch = {"7": {"rate": None}, "30": {"rate": None}}

        result = dashboard.evidence_state(metrics, touch)

        self.assertEqual(result["status"], "instrumentation-inactive")
        self.assertEqual(result["reasons"], ["no observed task starts"])

    def test_evidence_state_gates_on_reliable_first_pass(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 5,
            "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.6,
            "repair_rounds_mean": 0.2,
            "escape_7d_rate": 0.0,
            "telemetry_completeness": 1.0,
            "cost_coverage": 1.0,
            "observation_coverage": 0.8,
        }
        touch = {"7": {"rate": 0.0}, "30": {"rate": 0.0}}

        result = dashboard.evidence_state(metrics, touch)

        self.assertEqual(result["status"], "needs-attention")
        self.assertIn("reliable first-pass rate below 70%", result["reasons"])

    def test_objective_state_prioritizes_measurement_before_performance(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 6,
            "active_tasks": 0,
            "tasks": 6,
            "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.8,
            "repair_rounds_mean": 0.2,
            "escape_7d_rate": 0.0,
            "cost_coverage": 4 / 6,
            "cost_usd_known_tasks": 4,
            "telemetry_completeness": 1.0,
        }
        touch = {"30": {"rate": 10.0}}

        result = dashboard.objective_state(metrics, touch)

        self.assertEqual(result["status"], "not-measurable")
        self.assertEqual(result["primary_action"], "Registre o custo terminal de 2 resultado(s).")
        self.assertEqual(
            [gate["status"] for gate in result["gates"]],
            ["pass", "pass", "pass", "pass", "pass", "wait", "pass"],
        )

    def test_objective_state_reports_off_target_only_when_all_gates_are_known(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 5,
            "active_tasks": 0,
            "tasks": 5,
            "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.6,
            "repair_rounds_mean": 0.2,
            "escape_7d_rate": 0.0,
            "cost_coverage": 1.0,
            "cost_usd_known_tasks": 5,
            "telemetry_completeness": 1.0,
        }

        result = dashboard.objective_state(metrics, {"30": {"rate": 0.0}})

        self.assertEqual(result["status"], "off-target")
        self.assertIn("Reliable first-pass", result["primary_action"])

    def test_objective_state_surfaces_known_failure_while_prioritizing_missing_cost(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 5,
            "active_tasks": 0,
            "tasks": 5,
            "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.6,
            "repair_rounds_mean": 0.2,
            "repair_rounds_known_tasks": 5,
            "escape_7d_rate": 0.0,
            "cost_coverage": 0.8,
            "cost_usd_known_tasks": 4,
            "telemetry_completeness": 1.0,
        }

        result = dashboard.objective_state(metrics, {"30": {"rate": 0.0}})

        self.assertEqual(result["status"], "off-target")
        self.assertEqual(result["primary_action"], "Registre o custo terminal de 1 resultado(s).")

    def test_objective_state_reaches_on_target_when_all_gates_pass(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 5,
            "active_tasks": 0,
            "tasks": 5,
            "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.8,
            "repair_rounds_mean": 0.2,
            "repair_rounds_known_tasks": 5,
            "escape_7d_rate": 0.0,
            "cost_coverage": 1.0,
            "cost_usd_known_tasks": 5,
            "telemetry_completeness": 1.0,
        }

        result = dashboard.objective_state(metrics, {"30": {"rate": 10.0}})

        self.assertEqual(result["status"], "on-target")
        self.assertEqual(result["primary_action"], "Continue coletando resultados controlados.")

    def test_invalid_source_keeps_verdict_unmeasurable_without_hiding_gate_failure(self):
        dashboard = self.module("dashboard")
        metrics = {
            "started_tasks": 5, "tasks": 5, "reliable_first_pass_known": 5,
            "reliable_first_pass_rate": 0.6, "repair_rounds_mean": 0.2,
            "repair_rounds_known_tasks": 5, "escape_7d_rate": 0.0,
            "cost_coverage": 1.0, "cost_usd_known_tasks": 5,
            "telemetry_completeness": 1.0,
        }

        result = dashboard.objective_state(
            metrics, {"30": {"rate": 0.0}}, invalid_receipts=1,
        )

        self.assertEqual(result["status"], "not-measurable")
        self.assertEqual(result["primary_action"], "Corrija 1 fonte(s) de dados inválida(s) ou indisponível(is).")
        self.assertEqual(next(g for g in result["gates"] if g["key"] == "reliable")["status"], "fail")

    def test_objective_state_prioritizes_active_lifecycle_before_empty_cost(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_observations([], [
            {"task_id": "one"}, {"task_id": "two"}, {"task_id": "three"},
        ])

        result = dashboard.objective_state(metrics, {"30": {"rate": None}})

        self.assertEqual(result["status"], "not-measurable")
        self.assertEqual(result["primary_action"], "Conclua 3 tarefa(s) ativa(s) com 007 record.")

    def test_authority_confidence_separates_controlled_and_declared(self):
        dashboard = self.module("dashboard")
        result = dashboard.metrics_from_receipts([
            {"status": "accepted", "authority_evidence": "controlled", "authority_summary": {"bound": True}},
            {"status": "accepted", "authority_evidence": "declared", "authority_summary": {"bound": True}},
            {"status": "accepted"},
        ])

        self.assertEqual(result["authority_controlled_tasks"], 1)
        self.assertEqual(result["authority_declared_tasks"], 1)
        self.assertEqual(dashboard.authority_confidence(result), {
            "controlled": 1,
            "declared": 1,
            "unobserved": 1,
            "controlled_coverage": 0.5,
            "label": "mixed",
        })

    def test_outcome_trend_returns_daily_raw_counts(self):
        dashboard = self.module("dashboard")
        receipts = [
            {"status": "accepted", "first_pass": "yes", "escape_7d": "no", "completed_at": "2026-08-30T08:00:00Z"},
            {"status": "accepted", "first_pass": "no", "escape_7d": "no", "completed_at": "2026-08-30T09:00:00Z"},
            {"status": "blocked", "completed_at": "2026-08-31T10:00:00Z"},
        ]

        result = dashboard.outcome_trend(
            receipts, now=datetime(2026, 8, 31, 12, tzinfo=timezone.utc), days=3,
        )

        self.assertEqual(result, [
            {"date": "2026-08-29", "reliable": 0, "accepted_other": 0, "not_accepted": 0},
            {"date": "2026-08-30", "reliable": 1, "accepted_other": 1, "not_accepted": 0},
            {"date": "2026-08-31", "reliable": 0, "accepted_other": 0, "not_accepted": 1},
        ])

    def test_outcome_trend_excludes_controller_policy_blocks(self):
        dashboard = self.module("dashboard")
        receipts = [{
            "status": "blocked",
            "proof_reached": "controller-blocked-before-execution",
            "completed_at": "2026-08-31T10:00:00Z",
        }]

        result = dashboard.outcome_trend(
            receipts, now=datetime(2026, 8, 31, 12, tzinfo=timezone.utc), days=1,
        )

        self.assertEqual(result, [
            {"date": "2026-08-31", "reliable": 0, "accepted_other": 0, "not_accepted": 0},
        ])

    def test_aggregate_reconciles_trend_and_authority_across_projects(self):
        dashboard = self.module("dashboard")
        empty_metrics = dashboard.metrics_from_observations([], [])
        day = datetime.now(timezone.utc).date().isoformat()
        projects = [
            {
                "available": True,
                "metrics": {**empty_metrics, "tasks": 2, "authority_bound_tasks": 2,
                            "authority_controlled_tasks": 1, "authority_declared_tasks": 1},
                "touch": {"7": {"rate": 0.0}, "30": {"rate": 0.0}},
                "trend_30d": [{"date": day, "reliable": 1, "accepted_other": 0, "not_accepted": 0}],
                "invalid_receipts": [], "invalid_task_starts": [],
            },
            {
                "available": True,
                "metrics": {**empty_metrics, "tasks": 1},
                "touch": {"7": {"rate": 0.0}, "30": {"rate": 0.0}},
                "trend_30d": [{"date": day, "reliable": 0, "accepted_other": 1, "not_accepted": 0}],
                "invalid_receipts": [], "invalid_task_starts": [],
            },
            {
                "available": False,
                "metrics": {**empty_metrics, "tasks": 99, "authority_bound_tasks": 99,
                            "authority_controlled_tasks": 99},
                "touch": {"7": {"rate": None}, "30": {"rate": None}},
                "trend_30d": [{"date": day, "reliable": 99, "accepted_other": 0, "not_accepted": 0}],
                "invalid_receipts": [], "invalid_task_starts": [],
            },
        ]

        result = dashboard.aggregate_projects(projects)
        today = next(row for row in result["trend_30d"] if row["date"] == day)

        self.assertEqual(today, {"date": day, "reliable": 1, "accepted_other": 1, "not_accepted": 0})
        self.assertEqual(result["authority_confidence"], {
            "controlled": 1,
            "declared": 1,
            "unobserved": 1,
            "controlled_coverage": 0.5,
            "label": "mixed",
        })

    def test_aggregate_touch_is_unknown_when_any_project_is_missing(self):
        dashboard = self.module("dashboard")
        projects = [
            {"available": True, "touch": {"30": {
                "agent_lines_added": 10, "surviving_lines": 9, "rate": 10.0,
            }}},
            {"available": True, "touch": {"30": {
                "agent_lines_added": 0, "surviving_lines": 0, "rate": None,
                "reason": "no attributable agent commits",
            }}},
        ]

        result = dashboard.aggregate_touch(projects, 30)

        self.assertIsNone(result["rate"])
        self.assertEqual(result["known_projects"], 1)
        self.assertEqual(result["missing_projects"], 1)
        self.assertIn("1 of 2", result["reason"])

    def test_unavailable_project_blocks_evidence_but_not_touch_denominator(self):
        dashboard = self.module("dashboard")
        projects = [
            {"available": True, "touch": {"30": {
                "agent_lines_added": 10, "surviving_lines": 9, "rate": 10.0,
            }}},
            {"available": False, "touch": {"30": {"rate": None}}},
        ]

        result = dashboard.aggregate_touch(projects, 30)

        self.assertAlmostEqual(result["rate"], 10.0)
        self.assertEqual(result["known_projects"], 1)
        self.assertEqual(result["missing_projects"], 0)

    def test_unavailable_project_and_registry_error_block_aggregate_state(self):
        dashboard = self.module("dashboard")
        available = {"available": True, "metrics": dashboard.metrics_from_receipts([]),
                     "touch": {"7": {"rate": None}, "30": {"rate": None}},
                     "invalid_receipts": []}
        unavailable = {"available": False, "metrics": dashboard.metrics_from_receipts([]),
                       "touch": {"7": {"rate": None}, "30": {"rate": None}},
                       "invalid_receipts": []}

        result = dashboard.aggregate_projects([available, unavailable], registry_error_count=1)

        self.assertEqual(result["evidence"]["status"], "needs-attention")
        self.assertIn("1 unavailable project(s)", result["evidence"]["reasons"])
        self.assertIn("1 registry error(s)", result["evidence"]["reasons"])

    def test_cost_per_accepted_excludes_blocked_task_telemetry(self):
        dashboard = self.module("dashboard")
        project = {"available": True, "metrics": {
            "tasks": 2, "accepted": 1,
            "tokens_known_sum": 1099, "tokens_known_tasks": 2,
            "accepted_tokens_known_sum": 100, "accepted_tokens_known_tasks": 1,
            "wall_s_known_sum": 1010, "wall_s_known_tasks": 2,
            "accepted_wall_s_known_sum": 10, "accepted_wall_s_known_tasks": 1,
            "cost_usd_known_sum": 9.5, "cost_usd_known_tasks": 2,
            "accepted_cost_usd_known_sum": 0.5, "accepted_cost_usd_known_tasks": 1,
        }, "touch": {"7": {}, "30": {}}}

        result = dashboard.aggregate_projects([project])

        self.assertEqual(result["tokens_per_accepted"], 100)
        self.assertEqual(result["wall_s_per_accepted"], 10)
        self.assertEqual(result["cost_usd_per_accepted"], 0.5)

    def test_aggregate_roi_recomputes_from_raw_totals_not_project_averages(self):
        dashboard = self.module("dashboard")
        projects = []
        for cost, wall in ((0.2, 10), (0.8, 30)):
            metrics = dashboard.metrics_from_observations([{
                "task_id": f"task-{cost}", "task_class": "implement",
                "status": "accepted", "first_pass": "yes", "escape_7d": "no",
                "repair_rounds": 0, "served_provider": "openai",
                "served_model": "gpt-5.6-terra", "served_effort": "medium",
                "cost_usd": cost, "cost_source": "rate-card-estimate",
                "cost_status": "provisional", "wall_s": wall,
            }], [{"task_id": f"task-{cost}"}])
            projects.append({
                "available": True, "metrics": metrics,
                "touch": {"7": {"rate": 0.0}, "30": {"rate": 0.0}},
                "invalid_receipts": [], "invalid_task_starts": [],
            })

        result = dashboard.aggregate_projects(projects)

        self.assertEqual(result["reliable_outcomes_per_usd"], 2.0)
        self.assertEqual(result["wall_s_per_reliable"], 20.0)
        self.assertEqual(result["routes"][0]["reliable"], 2)
        self.assertEqual(result["routes"][0]["cost_usd_per_reliable"], 0.5)

    def test_routes_prefer_served_model_and_cost_requires_source(self):
        dashboard = self.module("dashboard")
        receipts = [
            {
                "status": "accepted",
                "requested_provider": "openai", "requested_model": "gpt-requested",
                "served_provider": "openai", "served_model": "gpt-served",
                "cost_usd": 0.4, "cost_source": "provider-reported", "cost_status": "final",
            },
            {
                "status": "accepted",
                "requested_provider": "moonshot", "requested_model": "kimi-k3",
                "cost_usd": 0.2,
            },
        ]

        metrics = dashboard.metrics_from_receipts(receipts)

        self.assertEqual(metrics["cost_usd_known_sum"], 0.4)
        self.assertEqual(metrics["cost_usd_known_tasks"], 1)
        self.assertEqual(metrics["cost_coverage"], 0.5)
        self.assertEqual(metrics["cost_final_tasks"], 1)
        self.assertEqual(metrics["cost_provisional_tasks"], 0)
        self.assertEqual(metrics["cost_usd_per_accepted"], None)
        routes = metrics["routes"]
        self.assertEqual([route["key"] for route in routes], [
            "moonshot/kimi-k3@effort-unmeasured", "openai/gpt-served@effort-unmeasured",
        ])
        self.assertEqual(routes[0]["task_class"], "unclassified")
        self.assertEqual(routes[0]["binding"], "requested-unverified")
        self.assertEqual(routes[0]["cost_usd_known_tasks"], 0)
        self.assertEqual(routes[1]["binding"], "served")
        self.assertEqual(routes[1]["cost_usd_known_sum"], 0.4)

    def test_route_metrics_expose_reliable_roi_without_hiding_failed_attempts(self):
        dashboard = self.module("dashboard")
        common = {
            "task_class": "implement", "served_provider": "openai",
            "served_model": "gpt-5.6-terra", "served_effort": "medium",
            "cost_source": "rate-card-estimate", "cost_status": "provisional",
        }
        metrics = dashboard.metrics_from_receipts([
            {**common, "status": "accepted", "first_pass": "yes", "escape_7d": "no", "cost_usd": 0.2, "wall_s": 10},
            {**common, "status": "blocked", "first_pass": "no", "escape_7d": "no", "cost_usd": 0.3, "wall_s": 20},
        ])

        route = metrics["routes"][0]
        self.assertEqual(route["task_class"], "implement")
        self.assertEqual(route["reliable"], 1)
        self.assertEqual(route["reliable_known"], 2)
        self.assertEqual(route["reliable_rate"], 0.5)
        self.assertEqual(route["cost_usd_per_reliable"], 0.5)
        self.assertEqual(route["wall_s_per_reliable"], 30.0)

    def test_route_metrics_keep_effort_bindings_separate(self):
        dashboard = self.module("dashboard")
        base = {
            "task_class": "implement", "served_provider": "openai",
            "served_model": "gpt-5.6-sol", "status": "accepted",
            "first_pass": "yes", "escape_7d": "no", "repair_rounds": 0,
            "cost_source": "provider-reported", "cost_status": "final", "wall_s": 10,
        }

        routes = dashboard.route_metrics([
            {**base, "served_effort": "medium", "cost_usd": 0.2},
            {**base, "served_effort": "xhigh", "cost_usd": 0.8},
        ])

        self.assertEqual(len(routes), 2)
        self.assertEqual({route["effort"] for route in routes}, {"medium", "xhigh"})

    def test_authority_metrics_separate_protection_from_friction(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_receipts([
            {"status": "accepted", "authority_summary": {
                "bound": True, "events": 6, "allowed_executions": 3,
                "protected_blocks": 1, "friction_blocks": 1,
                "unclassified_blocks": 1,
            }},
            {"status": "accepted"},
        ])

        self.assertEqual(metrics["authority_bound_tasks"], 1)
        self.assertEqual(metrics["authority_coverage"], 0.5)
        self.assertEqual(metrics["boundary_events"], 6)
        self.assertEqual(metrics["protected_blocks"], 1)
        self.assertEqual(metrics["friction_blocks"], 1)
        self.assertEqual(metrics["boundary_friction_rate"], 0.25)

    def test_aggregate_authority_friction_matches_project_denominator(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_receipts([{
            "status": "accepted",
            "authority_summary": {
                "bound": True, "events": 6, "allowed_executions": 3,
                "protected_blocks": 1, "friction_blocks": 1,
                "unclassified_blocks": 1,
            },
        }])
        project = {
            "available": True,
            "metrics": metrics,
            "touch": {
                "7": {"agent_lines_added": 0, "surviving_lines": 0, "rate": 0.0},
                "30": {"agent_lines_added": 0, "surviving_lines": 0, "rate": 0.0},
            },
        }

        aggregate = dashboard.aggregate_projects([project])

        self.assertEqual(aggregate["boundary_friction_rate"], 0.25)
        self.assertEqual(aggregate["authority_confidence"], {
            "controlled": 0,
            "declared": 1,
            "unobserved": 0,
            "controlled_coverage": 0.0,
            "label": "declared",
        })

    def test_telemetry_completeness_uses_served_route(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_receipts([{
            "status": "accepted",
            "served_provider": "anthropic",
            "served_model": "claude-opus-5",
            "served_effort": "xhigh",
            "tokens": 100,
            "wall_s": 2,
            "cost_usd": 0.1,
            "cost_source": "provider-reported",
            "cost_status": "final",
        }])

        self.assertEqual(metrics["telemetry_completeness"], 1.0)
        without_provider = dashboard.metrics_from_receipts([{
            "status": "accepted", "served_model": "claude-opus-5",
            "served_effort": "xhigh", "tokens": 100, "wall_s": 2,
        }])
        self.assertEqual(without_provider["telemetry_completeness"], 0.8)

    def test_preventive_controller_block_does_not_dilute_model_telemetry(self):
        dashboard = self.module("dashboard")
        metrics = dashboard.metrics_from_receipts([
            {
                "status": "accepted", "served_provider": "openai",
                "served_model": "gpt-5.6-sol", "served_effort": "xhigh",
                "tokens": 100, "wall_s": 2,
            },
            {
                "status": "blocked",
                "proof_reached": "controller-blocked-before-execution",
                "tokens": 0, "wall_s": 0,
            },
        ])

        self.assertEqual(metrics["telemetry_possible"], 5)
        self.assertEqual(metrics["telemetry_known"], 5)
        self.assertEqual(metrics["telemetry_completeness"], 1.0)

    def test_project_snapshot_sanitizes_receipts_and_preserves_unknowns(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "repo")
            repo.mkdir()
            (repo / ".git").mkdir()
            (repo / ".007/receipts").mkdir(parents=True)
            marker = {
                "schema": "007-framework/project/v1",
                "project_id": "project-1",
                "name": "Example",
                "receipt_dir": "receipts",
            }
            (repo / ".007/project.json").write_text(json.dumps(marker))
            (repo / ".007/receipts/task.receipt.json").write_text(json.dumps({
                "schema": "007-framework/receipt/v1",
                "task_id": "task-1",
                "status": "accepted",
                "proof_required": "integrated",
                "proof_reached": "integrated",
                "checks": [{"command": "secret command", "exit": 0, "tail": "secret"}],
                "delta": {"files": 2, "added": 10, "deleted": 1, "dependencies": 0},
                "first_pass": "yes",
                "repair_rounds": 0,
                "corrective_lines": "pending",
                "escape_7d": "pending",
                "model": ["malformed"],
                "effort": "medium",
                "tokens": "unmeasured",
                "wall_s": 12,
                "uncertainty": "runtime not exercised",
                "private_prompt": "must not escape",
                "authority_summary": {"private_detail": "must not escape"},
            }))
            entry = {
                "project_id": "project-1", "name": "Example",
                "path": str(repo), "registered_at": "2026-08-30T00:00:00Z",
            }
            no_touch = lambda _repo, days: {
                "window_days": days, "agent_commits": 0, "human_commits": 0,
                "agent_lines_added": 0, "surviving_lines": 0,
                "rate": None, "reason": "no attributable agent commits",
            }

            result = dashboard.project_snapshot(entry, touch_provider=no_touch)

            self.assertTrue(result["available"])
            self.assertEqual(result["metrics"]["tasks"], 1)
            self.assertEqual(result["metrics"]["first_pass_rate"], 1.0)
            self.assertIsNone(result["metrics"]["tokens_per_accepted"])
            self.assertEqual(result["metrics"]["tokens_missing_tasks"], 1)
            self.assertEqual(result["metrics"]["telemetry_completeness"], 0.4)
            self.assertEqual(result["recent_tasks"][0]["task_id"], "task-1")
            self.assertNotIn("checks", result["recent_tasks"][0])
            self.assertNotIn("private_prompt", result["recent_tasks"][0])
            self.assertNotIn("authority_summary", result["recent_tasks"][0])
            self.assertEqual(result["objective"]["status"], "not-measurable")
            self.assertEqual(result["authority_confidence"]["unobserved"], 1)
            self.assertEqual(len(result["trend_30d"]), 30)

    def test_touch_rate_exposes_structured_unknown_result(self):
        touch_rate = self.module("touch_rate")
        self.assertTrue(hasattr(touch_rate, "calculate"), "touch_rate.calculate is missing")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            Path(repo, "README.md").write_text("human\n")
            subprocess.run(["git", "add", "README.md"], cwd=repo, check=True)
            env = {
                **os.environ,
                "GIT_AUTHOR_NAME": "Human", "GIT_AUTHOR_EMAIL": "human@example.test",
                "GIT_COMMITTER_NAME": "Human", "GIT_COMMITTER_EMAIL": "human@example.test",
            }
            subprocess.run(["git", "commit", "-qm", "human"], cwd=repo, check=True, env=env)

            result = touch_rate.calculate(repo, days=30)

            self.assertIsNone(result["rate"])
            self.assertEqual(result["agent_commits"], 0)
            self.assertEqual(result["reason"], "no attributable agent commits")

    def test_snapshot_keeps_unavailable_projects_visible(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "available")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            registered = self.run_cli(
                "init", "--repo", str(repo), "--registry", str(registry)
            )
            self.assertEqual(registered.returncode, 0, registered.stderr)
            (repo / ".007/receipts/one.receipt.json").write_text(json.dumps({
                "schema": "007-framework/receipt/v1",
                "task_id": "one", "status": "accepted", "first_pass": "yes",
                "repair_rounds": 0, "escape_7d": "pending",
                "model": "unmeasured", "effort": "unmeasured",
                "tokens": "unmeasured", "wall_s": "unmeasured",
                "delta": {"files": 1, "added": 2, "deleted": 0},
            }))
            value = json.loads(registry.read_text())
            value["projects"].append({
                "project_id": "missing", "name": "Missing",
                "path": str(Path(tmp, "gone")),
                "registered_at": "2026-08-30T00:00:00Z",
            })
            registry.write_text(json.dumps(value))
            no_touch = lambda _repo, days: {
                "window_days": days, "agent_commits": 0, "human_commits": 0,
                "agent_lines_added": 0, "surviving_lines": 0,
                "rate": None, "reason": "no attribution",
            }

            snapshot = dashboard.build_snapshot(registry, touch_provider=no_touch)

            self.assertEqual(snapshot["aggregate"]["projects_total"], 2)
            self.assertEqual(snapshot["aggregate"]["projects_available"], 1)
            self.assertEqual(snapshot["aggregate"]["tasks"], 1)
            missing = next(item for item in snapshot["projects"] if item["project_id"] == "missing")
            self.assertFalse(missing["available"])

    def test_touch_cache_reuses_sensor_until_ttl_expires(self):
        dashboard = self.module("dashboard")
        calls = []
        clock = [100.0]

        def sensor(repo, days):
            calls.append((str(repo), days))
            return {"window_days": days, "rate": 1.0}

        cache = dashboard.TouchCache(sensor, ttl=60, clock=lambda: clock[0])
        first = cache(Path("/repo"), 30)
        clock[0] = 159.0
        second = cache(Path("/repo"), 30)
        clock[0] = 161.0
        third = cache(Path("/repo"), 30)

        self.assertIs(first, second)
        self.assertIsNot(second, third)
        self.assertEqual(len(calls), 2)

    def test_server_exposes_only_allowlisted_routes(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            static = Path(tmp, "static")
            static.mkdir()
            (static / "index.html").write_text("<!doctype html><title>007</title>")
            (static / "styles.css").write_text("body{}")
            (static / "app.js").write_text("'use strict';")
            registry = Path(tmp, "projects.json")
            server = dashboard.create_server("127.0.0.1", 0, registry, static)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base = f"http://127.0.0.1:{server.server_port}"
                with urlopen(base + "/api/health") as response:
                    self.assertEqual(json.load(response)["status"], "ok")
                    self.assertIn("default-src 'self'", response.headers["Content-Security-Policy"])
                with urlopen(base + "/api/snapshot") as response:
                    self.assertEqual(json.load(response)["aggregate"]["projects_total"], 0)
                with self.assertRaises(HTTPError) as denied:
                    urlopen(base + "/api/snapshot?path=/etc")
                self.assertEqual(denied.exception.code, 400)
                denied.exception.close()
                with self.assertRaises(HTTPError) as missing:
                    urlopen(base + "/../SKILL.md")
                self.assertEqual(missing.exception.code, 404)
                missing.exception.close()
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)

    def test_clean_project_e2e_records_cost_and_enters_snapshot(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "project")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            init = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))
            self.assertEqual(init.returncode, 0, init.stderr)
            begun = self.run_cli("begin", "--repo", str(repo), "--task-id", "e2e-task")
            self.assertEqual(begun.returncode, 0, begun.stderr)
            receipt = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
            receipt["task_id"] = "e2e-task"
            receipt["escape_7d"] = "no"
            source = Path(tmp, "receipt.json")
            source.write_text(json.dumps(receipt))
            recorded = self.run_cli("record", "--repo", str(repo), "--file", str(source))
            self.assertEqual(recorded.returncode, 0, recorded.stderr)

            snapshot = dashboard.build_snapshot(registry, touch_provider=lambda _repo, days: {
                "window_days": days, "agent_lines_added": 0, "surviving_lines": 0,
                "rate": None, "reason": "no attribution",
            })

            self.assertEqual(snapshot["aggregate"]["tasks"], 1)
            self.assertEqual(snapshot["aggregate"]["started_tasks"], 1)
            self.assertEqual(snapshot["aggregate"]["active_tasks"], 0)
            self.assertEqual(snapshot["aggregate"]["observation_coverage"], 1.0)
            self.assertEqual(snapshot["aggregate"]["reliable_first_pass_rate"], 1.0)
            self.assertEqual(snapshot["aggregate"]["cost_usd_per_reliable"], receipt["cost_usd"])
            self.assertEqual(snapshot["aggregate"]["cost_coverage"], 1.0)
            self.assertEqual(snapshot["aggregate"]["cost_usd_per_accepted"], receipt["cost_usd"])
            self.assertEqual(snapshot["aggregate"]["routes"][0]["binding"], "served")
            self.assertEqual(snapshot["measurement_boundary"]["cost_denominator"], "observed-terminal-receipts")
            self.assertEqual(
                snapshot["telemetry_fields"],
                ["provider", "model", "effort", "tokens", "wall_s"],
            )

    def test_snapshot_attaches_observed_activity_without_creating_outcomes(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp, "project")
            repo.mkdir()
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            registry = Path(tmp, "state", "projects.json")
            init = self.run_cli("init", "--repo", str(repo), "--registry", str(registry))
            self.assertEqual(init.returncode, 0, init.stderr)
            project_id = json.loads((repo / ".007/project.json").read_text())["project_id"]
            activity = {
                "window_hours": 24, "sessions": 2, "active_sessions": 1,
                "idle_sessions": 1, "tokens_total": 1200,
                "cost_usd_estimate": 0.42, "priced_sessions": 2,
                "unpriced_sessions": 0, "pricing_coverage": 1.0,
                "routes": [], "recent_sessions": [],
            }

            snapshot = dashboard.build_snapshot(
                registry,
                touch_provider=lambda _repo, days: {"window_days": days, "rate": None},
                activity_provider=lambda _entries: {
                    "aggregate": activity,
                    "projects": {project_id: activity},
                    "errors": [],
                },
            )

        self.assertEqual(snapshot["aggregate"]["activity"]["sessions"], 2)
        self.assertEqual(snapshot["projects"][0]["activity"]["tokens_total"], 1200)
        self.assertEqual(snapshot["aggregate"]["tasks"], 0)
        self.assertEqual(snapshot["aggregate"]["accepted"], 0)
        self.assertEqual(snapshot["aggregate"]["evidence"]["status"], "instrumentation-inactive")
        self.assertEqual(snapshot["activity_errors"], [])
        self.assertEqual(snapshot["measurement_boundary"]["cost_authority"], "terminal-receipt")

    def test_causal_evidence_loader_preserves_release_claim_and_boundary(self):
        dashboard = self.module("dashboard")
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp, "causal-roi.json")
            source.write_text(json.dumps({
                "schema": "007-framework/causal-roi/v1",
                "status": "supported-task-local",
                "claim": "NEW reduced estimated cost without quality loss.",
                "boundary": "Durability remains unmeasured.",
                "sample": {"tasks": 1, "cells": 6, "accepted": 6},
                "served_identity": {"verified_cells": 6, "total_cells": 6},
                "old": {"accepted": 3, "cost_usd_per_accepted": 0.38},
                "new": {"accepted": 3, "cost_usd_per_accepted": 0.29},
                "delta": {"cost_pct": -24.0},
            }))

            result = dashboard.load_causal_evidence(source)

        self.assertEqual(result["status"], "supported-task-local")
        self.assertEqual(result["sample"], {"tasks": 1, "cells": 6, "accepted": 6})
        self.assertEqual(result["delta"]["cost_pct"], -24.0)

    def test_causal_evidence_loader_fails_closed_when_artifact_is_missing(self):
        dashboard = self.module("dashboard")

        result = dashboard.load_causal_evidence(Path("/missing/causal-roi.json"))

        self.assertEqual(result["status"], "unavailable")
        self.assertIn("not available", result["boundary"])

    def test_dashboard_shell_is_semantic_and_self_contained(self):
        class ShellParser(HTMLParser):
            def __init__(self):
                super().__init__()
                self.tags = []
                self.urls = []
                self.live_regions = 0
                self.elements = []

            def handle_starttag(self, tag, attrs):
                self.tags.append(tag)
                values = dict(attrs)
                if values.get("id"):
                    self.elements.append(f"id:{values['id']}")
                self.elements.extend(f"class:{name}" for name in values.get("class", "").split())
                for key in ("src", "href"):
                    if values.get(key):
                        self.urls.append(values[key])
                self.live_regions += int("aria-live" in values)

        static = ROOT / "dashboard"
        self.assertTrue((static / "index.html").is_file(), "dashboard shell is missing")
        self.assertTrue((static / "styles.css").is_file(), "dashboard styles are missing")
        self.assertTrue((static / "app.js").is_file(), "dashboard application is missing")
        parser = ShellParser()
        parser.feed((static / "index.html").read_text())

        self.assertTrue({"header", "nav", "main", "section"}.issubset(parser.tags))
        self.assertGreaterEqual(parser.live_regions, 1)
        self.assertEqual(set(parser.urls), {"/styles.css", "/app.js"})
        self.assertFalse(any(url.startswith(("http://", "https://", "//")) for url in parser.urls))
        self.assertLess(parser.elements.index("id:causal-pricing"), parser.elements.index("class:causal-grid"))
        self.assertLess(parser.elements.index("class:causal-grid"), parser.elements.index("id:causal-spread"))
        self.assertLess(parser.elements.index("id:causal-spread"), parser.elements.index("id:causal-boundary"))

        shell = (static / "index.html").read_text()
        for required_id in (
            'id="instrumentation-panel"', 'id="metric-reliable"',
            'id="metric-reliable-cost"', 'id="reliability-funnel"',
            'id="funnel-started"', 'id="funnel-terminal"',
            'id="funnel-accepted"', 'id="funnel-first-pass"',
            'id="funnel-reliable"', 'id="runtime-activity-panel"',
            'id="activity-sessions"', 'id="activity-active"',
            'id="activity-tokens"', 'id="activity-cost"',
            'id="activity-equivalent-cost"',
            'id="authority-coverage"', 'id="authority-protected"',
            'id="authority-friction"', 'id="authority-friction-detail"',
            'id="authority-unclassified"',
            'id="primary-action"', 'id="gate-matrix-body"',
            'id="outcome-trend"', 'id="authority-controlled"',
            'id="authority-declared"', 'id="authority-unobserved"',
            'id="metric-roi"', 'id="metric-reliable-time"',
            'id="causal-strength"', 'id="causal-sample"',
            'id="causal-pricing"', 'id="causal-spread"',
            'id="causal-old-cost"', 'id="causal-new-cost"',
            'id="causal-cost-delta"', 'id="causal-latency-delta"',
        ):
            self.assertIn(required_id, shell)
        self.assertIn("O 007 está produzindo mais mudanças confiáveis por dólar", shell)
        self.assertIn("Atividade local não é outcome verificado", shell)
        self.assertIn("Codex · Claude · Kimi · Gemini", shell)
        self.assertIn("USD terminal observado", shell)
        app = (static / "app.js").read_text()
        self.assertIn('setText("authority-friction-detail"', app)
        self.assertIn('setText("causal-pricing"', app)
        self.assertIn('setText("causal-spread"', app)
        self.assertIn("evidence?.delta?.wall_per_accepted_pct", app)
        self.assertIn("createElementNS", app)
        self.assertNotIn(".innerHTML =", app)

    def unavailable_receipt(self, **overrides):
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        return {
            **base, "cost_usd": None, "cost_status": "unavailable",
            "cost_source": "custom:chatgpt-plan", "cost_unavailable_reason": "subscription route is unpriced",
            **overrides,
        }

    def test_receipt_cost_unavailable_requires_opt_in_and_all_four_fields(self):
        # gates 1, 2, 4
        cli = self.module("framework_cli")
        stored = cli.validate_receipt(self.unavailable_receipt(), allow_cost_unavailable=True)
        self.assertIsNone(stored["cost_usd"])
        self.assertIn("cost_usd", stored)
        self.assertEqual(stored["cost_status"], "unavailable")
        self.assertEqual(stored["cost_source"], "custom:chatgpt-plan")
        rejected = (
            ("numeric", {"cost_usd": 0.5}, "cost_status must be final or provisional"),
            ("zero", {"cost_usd": 0}, "cost_status must be final or provisional"),
            ("no-reason", {"cost_unavailable_reason": None}, "cost_unavailable_reason"),
            ("empty-reason", {"cost_unavailable_reason": ""}, "cost_unavailable_reason"),
            ("outside-namespace", {"cost_source": "provider-reported"}, "custom:<name>"),
            ("null-final", {"cost_status": "final"}, "cost_status unavailable"),
            ("null-provisional", {"cost_status": "provisional"}, "cost_status unavailable"),
        )
        for label, overrides, message in rejected:
            with self.subTest(label=label):
                with self.assertRaisesRegex(ValueError, message):
                    cli.validate_receipt(self.unavailable_receipt(**overrides), allow_cost_unavailable=True)
        missing_key = self.unavailable_receipt()
        del missing_key["cost_usd"]
        with self.assertRaisesRegex(ValueError, "cost_usd must be a non-negative measured number"):
            cli.validate_receipt(missing_key, allow_cost_unavailable=True)
        for opt_out in ({}, {"allow_cost_unavailable": False}):
            with self.subTest(opt_out=opt_out):
                with self.assertRaisesRegex(ValueError, "cost_usd must be a non-negative measured number"):
                    cli.validate_receipt(self.unavailable_receipt(), **opt_out)

    def test_marker_cost_unavailable_opt_in_is_strict_boolean(self):
        # gate 3
        cli = self.module("framework_cli")
        marker = {"schema": cli.PROJECT_SCHEMA, "project_id": "p", "name": "n", "receipt_dir": "receipts"}
        self.assertEqual(cli.validate_marker(dict(marker)), marker)
        for value in (True, False):
            self.assertIs(cli.validate_marker({**marker, "cost_unavailable_opt_in": value})["cost_unavailable_opt_in"], value)
        for value in (1, 0, "true", "false", None, [], {}):
            with self.subTest(value=value):
                with self.assertRaisesRegex(ValueError, "cost_unavailable_opt_in must be a boolean"):
                    cli.validate_marker({**marker, "cost_unavailable_opt_in": value})

    def run_with_marker_flip(self, tmp, initial, flipped, receipt, *extra):
        repo = Path(tmp, "repo")
        repo.mkdir()
        subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
        registry = Path(tmp, "state", "projects.json")
        self.assertEqual(self.run_cli("init", "--repo", str(repo), "--registry", str(registry)).returncode, 0)
        marker_path = repo / ".007/project.json"
        marker = json.loads(marker_path.read_text())
        if initial is not None:
            marker["cost_unavailable_opt_in"] = initial
        marker_path.write_text(json.dumps(marker))
        source = Path(tmp, "receipt.json")
        source.write_text(json.dumps(receipt))
        adapter = Path(tmp, "adapter.py")
        adapter.write_text(
            "import json, os, sys\n"
            "from pathlib import Path\n"
            "marker = Path(os.environ['FRAMEWORK_007_REPO'], '.007/project.json')\n"
            "marker.write_text(json.dumps({**json.loads(marker.read_text()), 'cost_unavailable_opt_in': " + repr(flipped) + "}))\n"
            "value = json.loads(Path(sys.argv[1]).read_text())\n"
            "value['task_id'] = os.environ['FRAMEWORK_007_TASK_ID']\n"
            "Path(os.environ['FRAMEWORK_007_RECEIPT_PATH']).write_text(json.dumps(value))\n"
        )
        result = self.run_cli(
            "run", "--repo", str(repo), "--task-id", "flip-001", "--receipt", "task.receipt.json",
            *extra, "--", sys.executable, str(adapter), str(source),
        )
        self.assertEqual(json.loads(marker_path.read_text())["cost_unavailable_opt_in"], flipped)
        return repo, result

    def test_run_captures_cost_policy_before_executor_can_change_it(self):
        # gate 5: the decision captured before begin_task prevails in both directions
        with tempfile.TemporaryDirectory() as tmp:
            repo, result = self.run_with_marker_flip(tmp, None, True, self.unavailable_receipt())
            self.assertEqual(result.returncode, 2)
            self.assertIn("cost_usd must be a non-negative measured number", result.stderr)
            self.assertTrue((repo / ".007/tasks/flip-001.task.json").is_file())
            self.assertFalse((repo / ".007/receipts/flip-001.receipt.json").exists())
        with tempfile.TemporaryDirectory() as tmp:
            repo, result = self.run_with_marker_flip(tmp, True, False, self.unavailable_receipt())
            self.assertEqual(result.returncode, 0, result.stderr)
            stored = json.loads((repo / ".007/receipts/flip-001.receipt.json").read_text())
            self.assertIsNone(stored["cost_usd"])
            self.assertEqual(stored["cost_status"], "unavailable")

    def test_unavailable_cost_survives_record_and_controlled_acceptance(self):
        # gate 6: persisted through run + bind_acceptance, and through standalone record
        with tempfile.TemporaryDirectory() as tmp:
            acceptance = Path(tmp, "acceptance.json")
            acceptance.write_text(json.dumps({
                "schema": "007-framework/acceptance/v1",
                "commands": [[sys.executable, "-c", "print('gate-ok')"]],
            }))
            repo, result = self.run_with_marker_flip(
                tmp, True, True, self.unavailable_receipt(), "--acceptance-file", str(acceptance),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            stored = json.loads((repo / ".007/receipts/flip-001.receipt.json").read_text())
            self.assertEqual(stored["acceptance_evidence"], "controlled")
            self.assertIn("cost_usd", stored)
            self.assertIsNone(stored["cost_usd"])
            self.assertEqual(stored["cost_status"], "unavailable")
            self.assertEqual(stored["cost_source"], "custom:chatgpt-plan")
            self.assertEqual(stored["cost_unavailable_reason"], "subscription route is unpriced")
            source = Path(tmp, "manual.json")
            source.write_text(json.dumps(self.unavailable_receipt(task_id="manual-001")))
            self.assertEqual(self.run_cli("begin", "--repo", str(repo), "--task-id", "manual-001").returncode, 0)
            recorded = self.run_cli("record", "--repo", str(repo), "--file", str(source))
            self.assertEqual(recorded.returncode, 0, recorded.stderr)
            manual = json.loads((repo / ".007/receipts/manual-001.receipt.json").read_text())
            self.assertEqual(manual["cost_status"], "unavailable")
            self.assertEqual(manual["cost_unavailable_reason"], "subscription route is unpriced")
        with tempfile.TemporaryDirectory() as tmp:
            repo, result = self.run_with_marker_flip(tmp, False, False, self.unavailable_receipt())
            self.assertEqual(result.returncode, 2)
            self.assertIn("cost_usd must be a non-negative measured number", result.stderr)

    def test_priced_receipts_are_unchanged_by_cost_unavailable_opt_in(self):
        # gate 9
        cli = self.module("framework_cli")
        dashboard = self.module("dashboard")
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        self.assertEqual(cli.validate_receipt(dict(base), allow_cost_unavailable=True), cli.validate_receipt(dict(base)))
        for cost in (0, 0.84):
            with self.subTest(cost=cost):
                self.assertEqual(cli.validate_receipt({**base, "cost_usd": cost}, allow_cost_unavailable=True)["cost_usd"], cost)
        with self.assertRaisesRegex(ValueError, "cost_status must be final or provisional"):
            cli.validate_receipt({**base, "cost_status": "unavailable"}, allow_cost_unavailable=True)
        receipts = [{**base, "task_id": f"t{index}", "cost_usd": 0.1 * index} for index in range(1, 4)]
        metrics = dashboard.metrics_from_receipts(receipts)
        self.assertEqual(metrics["cost_usd_known_tasks"], 3)
        self.assertEqual(metrics["cost_coverage"], 1.0)
        self.assertEqual(metrics["routes"][0]["cost_usd_known_tasks"], 3)

    def test_compatibility_regression_priced_receipt_keeps_cost_unavailable_reason(self):
        # priced receipts carrying the extension field validate unchanged under every policy state
        cli = self.module("framework_cli")
        base = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        for reason in ("legacy extension", "", None):
            for policy in ({}, {"allow_cost_unavailable": False}, {"allow_cost_unavailable": True}):
                with self.subTest(reason=reason, policy=policy):
                    expected = {**base, "cost_unavailable_reason": reason}
                    self.assertEqual(cli.validate_receipt(dict(expected), **policy), expected)

    def test_unavailable_cost_is_unaccounted_in_both_aggregators(self):
        # gate 10: dashboard and harness_report untouched, coverage < 1, ROI None
        dashboard = self.module("dashboard")
        report = self.module("harness_report")
        priced = json.loads((ROOT / "examples/task.receipt.example.json").read_text())
        receipts = [priced, self.unavailable_receipt(task_id="unpriced-001")]
        metrics = dashboard.metrics_from_receipts(receipts)
        self.assertEqual(metrics["cost_usd_known_tasks"], 1)
        self.assertEqual(metrics["cost_usd_known_sum"], 0.84)
        self.assertEqual(metrics["cost_coverage"], 0.5)
        self.assertIsNone(metrics["cost_usd_per_accepted"])
        self.assertEqual(metrics["routes"][0]["cost_usd_known_tasks"], 1)
        self.assertIsNone(metrics["routes"][0]["cost_usd_per_reliable"])
        summary = report.summarize(receipts, [])
        self.assertEqual(summary["cost_usd_known_tasks"], 1)
        self.assertEqual(summary["cost_unaccounted_tasks"], 1)
        self.assertEqual(summary["cost_coverage"], 0.5)
        self.assertIsNone(summary["cost_usd_per_accepted"])


if __name__ == "__main__":
    unittest.main()
