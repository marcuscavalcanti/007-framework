#!/usr/bin/env python3
"""Run paired policy replays in isolated temporary directories.

The accepted implementation is never exposed to the agent. Similarity metrics
are emitted only as diagnostics; repository-specific acceptance commands decide
whether a cell passes.
"""

import argparse
import difflib
import hashlib
import json
import math
import os
import random
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path


TASK_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")
DEPENDENCY_MANIFESTS = {
    "Cargo.toml", "Gemfile", "Pipfile", "go.mod", "package.json",
    "package-lock.json", "pnpm-lock.yaml", "poetry.lock", "pyproject.toml",
    "requirements.txt", "uv.lock", "yarn.lock",
}


def validate_task_id(value):
    if not isinstance(value, str) or not TASK_ID.fullmatch(value):
        raise ValueError(f"unsafe task id: {value!r}")
    return value


def run(args, cwd=None, timeout=1800, input_text=None):
    return subprocess.run(
        args, cwd=cwd, capture_output=True, text=True, timeout=timeout, input=input_text
    )


def new_archive_path(destination):
    fd, name = tempfile.mkstemp(
        prefix=f"{Path(destination).name}-", suffix=".tar", dir=Path(destination).parent
    )
    os.close(fd)
    return Path(name)


def extract_archive(archive, destination):
    destination_root = Path(destination).resolve()
    with tarfile.open(archive) as bundle:
        for member in bundle.getmembers():
            target = (destination_root / member.name).resolve()
            # This containment check is sound only while links and all other
            # non-regular entry types remain rejected below.
            if destination_root not in target.parents and target != destination_root:
                raise RuntimeError(f"unsafe archive member: {member.name}")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                target.chmod(0o755)
                continue
            if not member.isfile():
                raise RuntimeError(f"archive entry is not a regular file: {member.name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            source = bundle.extractfile(member)
            if source is None:
                raise RuntimeError(f"cannot read archive member: {member.name}")
            with source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            target.chmod(0o755 if member.mode & 0o111 else 0o644)


def export_snapshot(repo, revision, destination):
    archive = new_archive_path(destination)
    try:
        result = run(["git", "archive", "--format=tar", f"--output={archive}", revision], cwd=repo, timeout=300)
        if result.returncode:
            raise RuntimeError(result.stderr.strip()[:500])
        extract_archive(archive, destination)
    finally:
        archive.unlink(missing_ok=True)
    run(["git", "init", "-q"], cwd=destination)
    run(["git", "add", "-A"], cwd=destination)
    commit = run(
        ["git", "-c", "user.email=replay@local", "-c", "user.name=replay", "commit", "-qm", "base"],
        cwd=destination,
    )
    if commit.returncode:
        raise RuntimeError(commit.stderr.strip()[:500])


def changed_lines(repo, revision_range=None):
    args = ["git", "diff"]
    if revision_range:
        args.append(revision_range)
    result = run(args, cwd=repo, timeout=300)
    files, lines = set(), []
    for line in result.stdout.splitlines():
        if line.startswith("+++ b/"):
            files.add(line[6:])
        elif line.startswith("+") and not line.startswith("+++"):
            lines.append(line[1:].strip())
    return files, sorted(lines)


def diagnostics(task, workspace, source_repo):
    run(["git", "add", "-N", "--", "."], cwd=workspace, timeout=60)
    produced_files, produced_lines = changed_lines(workspace)
    numstat = run(["git", "diff", "--numstat"], cwd=workspace, timeout=300)
    added = deleted = 0
    binary = []
    complete = numstat.returncode == 0
    for line in numstat.stdout.splitlines():
        parts = line.split("\t", 2)
        if len(parts) == 3 and parts[0] == parts[1] == "-":
            binary.append(parts[2])
            continue
        if len(parts) != 3 or not parts[0].isdigit() or not parts[1].isdigit():
            complete = False
            continue
        added += int(parts[0])
        deleted += int(parts[1])
    accepted_files, accepted_lines = changed_lines(
        source_repo, f"{task['base']}..{task['accepted']}"
    )
    union = produced_files | accepted_files
    return {
        "d0_complete": complete,
        "changed_files": len(produced_files),
        "lines_added": added,
        "lines_deleted": deleted,
        "binary_files_changed": sorted(binary),
        "dependency_manifests_changed": sorted(
            path for path in produced_files if Path(path).name in DEPENDENCY_MANIFESTS
        ),
        "file_jaccard_diagnostic": round(len(produced_files & accepted_files) / len(union), 3) if union else 0.0,
        "line_similarity_diagnostic": round(
            difflib.SequenceMatcher(None, "\n".join(produced_lines), "\n".join(accepted_lines)).ratio(), 3
        ) if produced_lines and accepted_lines else 0.0,
    }


def acceptance(task, workspace):
    results = []
    for command in task.get("acceptance", []):
        argv = command if isinstance(command, list) else shlex.split(command)
        result = run(argv, cwd=workspace, timeout=task.get("acceptance_timeout_s", 900))
        results.append({"command": argv, "exit": result.returncode, "tail": (result.stdout + result.stderr)[-1000:]})
    return results, bool(results) and all(item["exit"] == 0 for item in results)


def hidden_target(workspace, value):
    relative = Path(value)
    if relative.is_absolute() or not relative.parts or ".." in relative.parts:
        raise ValueError(f"unsafe hidden acceptance target: {value!r}")
    root = Path(workspace).resolve()
    target = root / relative
    current = root
    for part in relative.parts[:-1]:
        current /= part
        if current.is_symlink() or (current.exists() and not current.is_dir()):
            raise ValueError(f"unsafe hidden acceptance parent: {value!r}")
        current.mkdir(exist_ok=True)
    if target.is_symlink() or (target.exists() and not target.is_file()):
        raise ValueError(f"unsafe hidden acceptance target: {value!r}")
    return target


@contextmanager
def hidden_acceptance(task, workspace):
    backups = []
    try:
        for entry in task.get("hidden_acceptance", []):
            source = Path(entry["source"]).expanduser().resolve()
            hidden_bytes = source.read_bytes()
            digest = hashlib.sha256(hidden_bytes).hexdigest()
            if not SHA256.fullmatch(entry.get("sha256", "")) or digest != entry["sha256"]:
                raise ValueError(f"hidden acceptance hash mismatch: {source}")
            target = hidden_target(workspace, entry["target"])
            backups.append((entry["target"], target.read_bytes() if target.exists() else None))
            target.write_bytes(hidden_bytes)
        yield
    finally:
        for value, previous in reversed(backups):
            target = hidden_target(workspace, value)
            if previous is None:
                target.unlink(missing_ok=True)
            else:
                target.write_bytes(previous)


def grade_cell(agent_exit, checks_passed):
    valid = agent_exit == 0
    return valid, valid and checks_passed


def validate_served_identity(value, policy):
    if value is None:
        return None, "served-identity-missing"
    if not isinstance(value, dict) or value.get("schema") != "007-framework/runner-receipt/v1":
        return None, "runner-receipt-invalid"
    if value.get("valid") is not True:
        return None, "runner-invalid"
    if value.get("requested") != {key: policy.get(key) for key in ("provider", "model", "effort")}:
        return None, "requested-policy-mismatch"
    served = value.get("served")
    if not isinstance(served, dict):
        return None, "served-identity-missing"
    for key in ("provider", "model", "effort"):
        if served.get(key) != policy.get(key):
            return None, f"served-{key}-mismatch"
    if not isinstance(value.get("identity_source"), str) or not value["identity_source"]:
        return None, "identity-source-missing"
    if not isinstance(value.get("source_sha256"), str) or not SHA256.fullmatch(value["source_sha256"]):
        return None, "identity-source-hash-invalid"
    cost = value.get("cost_usd")
    if (
        isinstance(cost, bool) or not isinstance(cost, (int, float))
        or not math.isfinite(cost) or cost < 0
    ):
        return None, "cost-missing"
    if not isinstance(value.get("cost_source"), str) or not value["cost_source"]:
        return None, "cost-source-missing"
    return {
        **served,
        "identity_source": value["identity_source"],
        "source_sha256": value["source_sha256"],
        "usage": value.get("usage"),
        "cost_usd": cost,
        "cost_source": value["cost_source"],
    }, None


def experiment_seed(config):
    seed = config.get("seed")
    if not isinstance(seed, int) or isinstance(seed, bool):
        raise ValueError("replay set requires an integer seed fixed before execution")
    return seed


def experiment_replicates(config, requested):
    configured = config.get("replicates_per_arm_task")
    if configured is None:
        configured = 1 if requested is None else requested
    if not isinstance(configured, int) or isinstance(configured, bool) or configured < 1:
        raise ValueError("replicates_per_arm_task must be a positive integer")
    if requested is not None and requested != configured:
        raise ValueError("--replicates does not match the frozen replay set")
    return configured


def experiment_schedule(config, arms, replicates):
    rng = random.Random(experiment_seed(config))
    schedule = {}
    for task in config["tasks"]:
        for replicate in range(1, replicates + 1):
            pair = arms[:]
            rng.shuffle(pair)
            schedule[(task["id"], replicate)] = pair
    return schedule


def write_summary(output_dir, replay_set, config, replicates, rows):
    (output_dir / "summary.json").write_text(
        json.dumps({
            "experiment_id": config.get("experiment_id"),
            "replay_set_sha256": hashlib.sha256(replay_set.read_bytes()).hexdigest(),
            "seed": experiment_seed(config),
            "replicates_per_arm_task": replicates,
            "cells": rows,
        }, indent=2)
    )


def execute_cell(config, task, arm, replicate, output_dir, timeout_s):
    validate_task_id(task["id"])
    source_repo = Path(config["repos"][task["repo"]]).expanduser().resolve()
    policy = config["arms"][arm]
    workspace = Path(tempfile.mkdtemp(prefix=f"007-{task['id']}-{arm}-r{replicate:02d}-"))
    try:
        export_snapshot(source_repo, task["base"], workspace)
        prompt = workspace / ".007-prompt.txt"
        prompt.write_text(task["prompt"] + "\n\n" + policy["doctrine"])
        runner_receipt = output_dir / f"{task['id']}-r{replicate:02d}-{arm}.runner.json"
        if runner_receipt.exists():
            raise RuntimeError(f"runner receipt already exists: {runner_receipt}")
        replacements = {
            "{cwd}": str(workspace), "{prompt_file}": str(prompt),
            "{model}": policy["model"], "{effort}": policy["effort"],
            "{runner_receipt}": str(runner_receipt),
        }
        argv = []
        for part in config["agent_command"]:
            for marker, value in replacements.items():
                part = part.replace(marker, value)
            argv.append(part)
        started = time.monotonic()
        try:
            agent = run(argv, cwd=workspace, timeout=timeout_s, input_text=prompt.read_text())
            exit_code, tail = agent.returncode, (agent.stdout + agent.stderr)[-1500:]
        except subprocess.TimeoutExpired:
            exit_code, tail = -9, "TIMEOUT"
        prompt.unlink(missing_ok=True)
        hidden_failure = None
        try:
            with tempfile.TemporaryDirectory(prefix=f"007-acceptance-{task['id']}-") as acceptance_tmp:
                acceptance_workspace = Path(acceptance_tmp) / "workspace"
                shutil.copytree(workspace, acceptance_workspace, symlinks=True)
                with hidden_acceptance(task, acceptance_workspace):
                    checks, checks_passed = acceptance(task, acceptance_workspace)
        except (OSError, ValueError, RuntimeError) as exc:
            checks, checks_passed = [], False
            hidden_failure = f"hidden-acceptance-{type(exc).__name__.lower()}"
        try:
            runner_value = json.loads(runner_receipt.read_text()) if runner_receipt.is_file() else None
        except json.JSONDecodeError:
            runner_value = {}
        identity, identity_failure = (
            validate_served_identity(runner_value, policy)
            if config.get("require_served_identity") else (None, None)
        )
        d0 = diagnostics(task, workspace, source_repo)
        d0_failure = None if d0["d0_complete"] else "d0-incomplete"
        agent_valid, _ = grade_cell(exit_code, checks_passed)
        valid = agent_valid and identity_failure is None and hidden_failure is None and d0["d0_complete"]
        accepted = valid and checks_passed
        failure_class = (
            "timeout" if exit_code == -9 else "agent-exit" if exit_code != 0
            else hidden_failure or identity_failure or d0_failure or "none"
        )
        usage = identity.get("usage") if identity else None
        record = {
            "schema": "007-framework/replay-cell/v1",
            "task": task["id"],
            "arm": arm,
            "replicate": replicate,
            "requested_provider": policy.get("provider", "unmeasured"),
            "requested_model": policy["model"],
            "requested_effort": policy["effort"],
            "served_provider": identity["provider"] if identity else "unmeasured",
            "served_model": identity["model"] if identity else "unmeasured",
            "served_effort": identity["effort"] if identity else "unmeasured",
            "identity_source": identity["identity_source"] if identity else "unmeasured",
            "identity_source_sha256": identity["source_sha256"] if identity else "unmeasured",
            "runner_receipt_sha256": (
                hashlib.sha256(runner_receipt.read_bytes()).hexdigest()
                if runner_receipt.is_file() else "unmeasured"
            ),
            "usage": usage if usage is not None else "unmeasured",
            "tokens": usage.get("total_tokens", "unmeasured") if isinstance(usage, dict) else "unmeasured",
            "cost_usd": identity["cost_usd"] if identity else "unmeasured",
            "cost_source": identity["cost_source"] if identity else "unmeasured",
            "agent_exit": exit_code,
            "wall_s": round(time.monotonic() - started, 2),
            "valid": valid,
            "accepted": accepted,
            "failure_class": failure_class,
            "acceptance": checks,
            **d0,
            "agent_tail": tail,
        }
        (output_dir / f"{task['id']}-r{replicate:02d}-{arm}.json").write_text(json.dumps(record, indent=2))
        return record
    finally:
        shutil.rmtree(workspace)


def main():
    parser = argparse.ArgumentParser(description="Run frozen OLD×NEW coding replays")
    parser.add_argument("--set", required=True)
    parser.add_argument("command", choices=("list", "run"))
    parser.add_argument("--tasks", default="all", help="all or comma-separated task ids")
    parser.add_argument("--arms", default="OLD,NEW")
    parser.add_argument("--out", default="replay-results")
    parser.add_argument("--timeout-min", type=int, default=30)
    parser.add_argument("--replicates", type=int)
    args = parser.parse_args()
    replay_set = Path(args.set).expanduser().resolve()
    config = json.loads(replay_set.read_text())
    tasks = config["tasks"]
    for task in tasks:
        validate_task_id(task["id"])
    if args.command == "list":
        for task in tasks:
            print(f"{task['id']:24s} {task.get('class', 'unclassified'):12s} {task.get('subject', '')}")
        return 0

    wanted = None if args.tasks == "all" else set(args.tasks.split(","))
    tasks = [task for task in tasks if wanted is None or task["id"] in wanted]
    arms = args.arms.split(",")
    unknown = set(arms) - set(config["arms"])
    if unknown:
        parser.error(f"unknown arms: {sorted(unknown)}")
    output_dir = Path(args.out).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    replicates = experiment_replicates(config, args.replicates)
    schedule = experiment_schedule(config, arms, replicates)
    rows = []
    for task in tasks:
        for replicate in range(1, replicates + 1):
            for arm in schedule[(task["id"], replicate)]:
                record = execute_cell(config, task, arm, replicate, output_dir, args.timeout_min * 60)
                record["execution_index"] = len(rows) + 1
                rows.append(record)
                if not record["valid"]:
                    write_summary(output_dir, replay_set, config, replicates, rows)
                    print(f"invalid cell: {task['id']} r{replicate:02d} {arm}; stopped", file=sys.stderr)
                    return 2
    write_summary(output_dir, replay_set, config, replicates, rows)
    print(f"wrote {len(rows)} cells to {output_dir}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        sys.exit(2)
