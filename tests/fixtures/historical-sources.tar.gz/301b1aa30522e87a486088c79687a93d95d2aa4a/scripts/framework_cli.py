#!/usr/bin/env python3
"""Local project registration and dashboard entrypoint for 007 Framework."""

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from pathlib import Path


PROJECT_SCHEMA = "007-framework/project/v1"
REGISTRY_SCHEMA = "007-framework/registry/v1"
RECEIPT_SCHEMA = "007-framework/receipt/v1"
TASK_START_SCHEMA = "007-framework/task-start/v1"
AUTHORITY_SCHEMA = "007-framework/authority/v1"
CONTROLLER_EVENT_SCHEMA = "007-framework/controller-event/v1"
ROUTE_CONFIG_SCHEMA = "007-framework/routes/v1"
ROUTE_DECISION_SCHEMA = "007-framework/route-decision/v1"
ACCEPTANCE_SCHEMA = "007-framework/acceptance/v1"
TASK_CLASSES = {"inspect", "implement", "deep", "design"}
TASK_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")
COST_SOURCES = {
    "provider-reported", "rate-card-estimate", "subscription-allocated", "local-compute",
}
CUSTOM_COST_SOURCE = re.compile(r"^custom:[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


def default_registry_path():
    return Path.home() / ".007-framework" / "projects.json"


def default_route_config_path():
    return Path.home() / ".007-framework" / "routes.json"


def git_root(path):
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=Path(path).expanduser(),
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode:
        raise ValueError(f"not a Git repository: {Path(path).expanduser()}")
    return Path(result.stdout.strip()).resolve()


def exclude_local_state(root):
    result = subprocess.run(
        ["git", "rev-parse", "--git-path", "info/exclude"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode:
        raise ValueError("cannot locate Git exclude file")
    path = Path(result.stdout.strip())
    if not path.is_absolute():
        path = root / path
    marker = "/.007/"
    current = path.read_text() if path.exists() else ""
    if marker not in current.splitlines():
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a") as output:
            if current and not current.endswith("\n"):
                output.write("\n")
            output.write(marker + "\n")


def read_json(path):
    return json.loads(path.read_text())


def write_json_atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(handle, "w") as output:
            json.dump(value, output, indent=2, sort_keys=True)
            output.write("\n")
        os.replace(name, path)
    except BaseException:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass
        raise


def write_json_no_replace(path, value, label="receipt"):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(handle, "w") as output:
            json.dump(value, output, indent=2, sort_keys=True)
            output.write("\n")
        try:
            os.link(name, path)
        except FileExistsError as exc:
            raise ValueError(f"{label} already exists: {path.name}") from exc
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass


def validate_marker(value):
    if not isinstance(value, dict) or value.get("schema") != PROJECT_SCHEMA:
        raise ValueError("invalid .007/project.json schema")
    if not all(isinstance(value.get(key), str) and value[key] for key in ("project_id", "name", "receipt_dir")):
        raise ValueError("invalid .007/project.json fields")
    receipt_dir = Path(value["receipt_dir"])
    if receipt_dir.is_absolute() or ".." in receipt_dir.parts:
        raise ValueError("receipt_dir must stay inside .007")
    return value


def receipt_directory(marker_path, marker):
    state_dir = marker_path.parent.resolve()
    receipt_dir = (state_dir / marker["receipt_dir"]).resolve()
    if not receipt_dir.is_relative_to(state_dir):
        raise ValueError("receipt_dir must stay inside .007")
    return receipt_dir


def load_registry(path):
    if not path.exists():
        return {"schema": REGISTRY_SCHEMA, "projects": []}
    value = read_json(path)
    if not isinstance(value, dict) or value.get("schema") != REGISTRY_SCHEMA or not isinstance(value.get("projects"), list):
        raise ValueError(f"invalid registry: {path}")
    required = ("project_id", "name", "path", "registered_at")
    if any(
        not isinstance(item, dict)
        or not all(isinstance(item.get(key), str) and item[key] for key in required)
        for item in value["projects"]
    ):
        raise ValueError(f"invalid registry entry: {path}")
    return value


def validate_task_id(task_id):
    if not isinstance(task_id, str) or not TASK_ID.fullmatch(task_id):
        raise ValueError("task_id must use only letters, numbers, dot, dash, or underscore")
    return task_id


def validate_route_config(value):
    if not isinstance(value, dict) or value.get("schema") != ROUTE_CONFIG_SCHEMA:
        raise ValueError(f"route config schema must be {ROUTE_CONFIG_SCHEMA}")
    candidates = value.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        raise ValueError("route config requires candidates")
    seen = set()
    for candidate in candidates:
        if not isinstance(candidate, dict):
            raise ValueError("route candidate must be an object")
        candidate_id = validate_task_id(candidate.get("id"))
        if candidate_id in seen:
            raise ValueError(f"duplicate route candidate: {candidate_id}")
        seen.add(candidate_id)
        command = candidate.get("command")
        classes = candidate.get("task_classes")
        if not isinstance(command, list) or not command or any(not isinstance(part, str) or not part for part in command):
            raise ValueError(f"route candidate {candidate_id} requires command argv")
        if not isinstance(classes, list) or not classes or set(classes) - TASK_CLASSES:
            raise ValueError(f"route candidate {candidate_id} has invalid task_classes")
        for field in ("provider", "model", "effort"):
            if not isinstance(candidate.get(field), str) or not candidate[field]:
                raise ValueError(f"route candidate {candidate_id} requires {field}")
        if "fallback" in candidate and not isinstance(candidate["fallback"], bool):
            raise ValueError(f"route candidate {candidate_id} fallback must be boolean")
    return value


def route_performance(candidate, receipts, task_class):
    matching = [
        receipt for receipt in receipts
        if receipt.get("task_class") == task_class
        and (receipt.get("served_provider") or receipt.get("provider")) == candidate["provider"]
        and (receipt.get("served_model") or receipt.get("model")) == candidate["model"]
        and (receipt.get("served_effort") or receipt.get("effort")) == candidate["effort"]
    ]
    reliable = [
        receipt for receipt in matching
        if receipt.get("status") == "accepted"
        and receipt.get("first_pass") == "yes"
        and receipt.get("escape_7d") in (False, "no")
    ]
    mature = [
        receipt for receipt in matching
        if receipt.get("first_pass") in ("yes", "no")
        and receipt.get("escape_7d") in (True, False, "yes", "no")
    ]
    repairs = [receipt.get("repair_rounds") for receipt in matching]
    costs_known = all(
        isinstance(receipt.get("cost_usd"), (int, float))
        and not isinstance(receipt.get("cost_usd"), bool)
        and math.isfinite(receipt["cost_usd"])
        and isinstance(receipt.get("cost_source"), str)
        and receipt.get("cost_status") in ("final", "provisional")
        for receipt in matching
    )
    wall_known = all(
        isinstance(receipt.get("wall_s"), (int, float))
        and not isinstance(receipt.get("wall_s"), bool)
        and math.isfinite(receipt["wall_s"])
        for receipt in matching
    )
    reliable_rate = len(reliable) / len(mature) if mature else None
    escape_rate = sum(receipt.get("escape_7d") in (True, "yes") for receipt in mature) / len(mature) if mature else None
    repairs_mean = sum(repairs) / len(repairs) if matching and all(isinstance(value, int) and not isinstance(value, bool) for value in repairs) else None
    return {
        "tasks": len(matching),
        "mature": len(mature),
        "reliable": len(reliable),
        "reliable_rate": reliable_rate,
        "escape_rate": escape_rate,
        "repair_rounds_mean": repairs_mean,
        "cost_usd_per_reliable": (
            round(sum(receipt["cost_usd"] for receipt in matching) / len(reliable), 6)
            if matching and reliable and costs_known else None
        ),
        "wall_s_per_reliable": (
            round(sum(receipt["wall_s"] for receipt in matching) / len(reliable), 3)
            if matching and reliable and wall_known else None
        ),
    }


def select_route(candidates, receipts, task_class, which=shutil.which):
    if task_class not in TASK_CLASSES:
        raise ValueError(f"task_class must be one of: {', '.join(sorted(TASK_CLASSES))}")
    available = [
        candidate for candidate in candidates
        if task_class in candidate.get("task_classes", []) and which(candidate["command"][0])
    ]
    measured, rejected = [], {}
    for candidate in available:
        performance = route_performance(candidate, receipts, task_class)
        reasons = []
        if performance["mature"] < 5:
            reasons.append("fewer than 5 mature outcomes")
        if performance["reliable_rate"] is None or performance["reliable_rate"] < 0.7:
            reasons.append("reliable first-pass below 70%")
        if performance["escape_rate"] is None or performance["escape_rate"] > 0.05:
            reasons.append("escape rate above 5%")
        if performance["repair_rounds_mean"] is None or performance["repair_rounds_mean"] > 0.5:
            reasons.append("repair rounds above 0.5")
        if performance["cost_usd_per_reliable"] is None:
            reasons.append("cost coverage incomplete")
        if performance["wall_s_per_reliable"] is None:
            reasons.append("latency coverage incomplete")
        if reasons:
            rejected[candidate["id"]] = reasons
        else:
            measured.append({**candidate, **performance})
    measured.sort(key=lambda item: (item["cost_usd_per_reliable"], item["wall_s_per_reliable"], item["id"]))
    selected = measured[0] if measured else next((item for item in available if item.get("fallback")), None)
    return {
        "schema": ROUTE_DECISION_SCHEMA,
        "task_class": task_class,
        "strategy": "measured" if measured else "policy-fallback" if selected else "blocked",
        "selected": selected,
        "available_candidates": len(available),
        "eligible_candidates": len(measured),
        "rejected": rejected,
    }


def load_route_receipts(repo):
    root = git_root(repo)
    marker_path = root / ".007" / "project.json"
    if not marker_path.is_file():
        return []
    receipts = []
    marker = validate_marker(read_json(marker_path))
    for path in sorted(receipt_directory(marker_path, marker).glob("*.receipt.json")):
        value = read_json(path)
        if not isinstance(value, dict):
            raise ValueError(f"invalid route receipt: {path}")
        receipts.append(value)
    return receipts


def validate_authority(value):
    if not isinstance(value, dict) or value.get("schema") != AUTHORITY_SCHEMA:
        raise ValueError(f"authority schema must be {AUTHORITY_SCHEMA}")
    for key in ("allow", "deny"):
        actions = value.get(key)
        if not isinstance(actions, list) or any(not isinstance(action, str) or not TASK_ID.fullmatch(action) for action in actions):
            raise ValueError(f"authority {key} must be a list of action names")
        if len(actions) != len(set(actions)):
            raise ValueError(f"authority {key} contains duplicate actions")
    if set(value["allow"]) & set(value["deny"]):
        raise ValueError("authority actions cannot be both allowed and denied")
    return value


def read_authority(path):
    payload = Path(path).expanduser().read_bytes()
    authority = validate_authority(json.loads(payload))
    return authority, hashlib.sha256(payload).hexdigest()


def validate_task_start(value):
    if not isinstance(value, dict) or value.get("schema") != TASK_START_SCHEMA:
        raise ValueError(f"task start schema must be {TASK_START_SCHEMA}")
    validate_task_id(value.get("task_id"))
    if not isinstance(value.get("started_at"), str) or not value["started_at"]:
        raise ValueError("started_at must be a timestamp string")
    authority = value.get("authority")
    authority_hash = value.get("authority_sha256")
    if authority is not None or authority_hash is not None:
        validate_authority(authority)
        if not isinstance(authority_hash, str) or not SHA256.fullmatch(authority_hash):
            raise ValueError("authority_sha256 must be a lowercase SHA-256")
    acceptance = value.get("acceptance")
    acceptance_hash = value.get("acceptance_sha256")
    if acceptance is not None or acceptance_hash is not None:
        validate_acceptance(acceptance)
        if not isinstance(acceptance_hash, str) or not SHA256.fullmatch(acceptance_hash):
            raise ValueError("acceptance_sha256 must be a lowercase SHA-256")
    return value


def validate_acceptance(value):
    if not isinstance(value, dict) or value.get("schema") != ACCEPTANCE_SCHEMA:
        raise ValueError(f"acceptance schema must be {ACCEPTANCE_SCHEMA}")
    commands = value.get("commands")
    if (
        not isinstance(commands, list) or not commands
        or any(
            not isinstance(command, list) or not command
            or any(not isinstance(part, str) or not part for part in command)
            for command in commands
        )
    ):
        raise ValueError("acceptance commands must be non-empty argv arrays")
    timeout_s = value.get("timeout_s", 900)
    if isinstance(timeout_s, bool) or not isinstance(timeout_s, int) or not 1 <= timeout_s <= 3600:
        raise ValueError("acceptance timeout_s must be an integer from 1 to 3600")
    return value


def read_acceptance(path):
    payload = Path(path).expanduser().read_bytes()
    return validate_acceptance(json.loads(payload)), hashlib.sha256(payload).hexdigest()


def init_project(repo, registry_path, now=None):
    root = git_root(repo)
    exclude_local_state(root)
    marker_path = root / ".007" / "project.json"
    if marker_path.exists():
        marker = validate_marker(read_json(marker_path))
    else:
        marker = {
            "schema": PROJECT_SCHEMA,
            "project_id": str(uuid.uuid4()),
            "name": root.name,
            "receipt_dir": "receipts",
        }
        write_json_atomic(marker_path, marker)
    receipt_directory(marker_path, marker).mkdir(parents=True, exist_ok=True)

    registry_path = Path(registry_path).expanduser().resolve()
    registry = load_registry(registry_path)
    existing = next(
        (item for item in registry["projects"] if item.get("project_id") == marker["project_id"]),
        None,
    )
    registered_at = (existing or {}).get("registered_at")
    if not registered_at:
        instant = now or datetime.now(timezone.utc)
        registered_at = instant.isoformat().replace("+00:00", "Z")
    entry = {
        "project_id": marker["project_id"],
        "name": marker["name"],
        "path": str(root),
        "registered_at": registered_at,
    }
    registry["projects"] = [
        item for item in registry["projects"]
        if item.get("project_id") != marker["project_id"] and item.get("path") != str(root)
    ] + [entry]
    registry["projects"].sort(key=lambda item: (item.get("name", "").lower(), item.get("path", "")))
    write_json_atomic(registry_path, registry)
    return entry


def unregister_project(project, registry_path):
    registry_path = Path(registry_path).expanduser().resolve()
    registry = load_registry(registry_path)
    target_path = str(Path(project).expanduser().resolve())
    removed = [
        item for item in registry["projects"]
        if item["project_id"] == project or item["path"] == target_path
    ]
    if not removed:
        raise ValueError(f"project is not registered: {project}")
    registry["projects"] = [item for item in registry["projects"] if item not in removed]
    write_json_atomic(registry_path, registry)
    return removed[0]


def begin_task(repo, task_id=None, now=None, authority_file=None, acceptance_file=None):
    root = git_root(repo)
    marker_path = root / ".007" / "project.json"
    if not marker_path.exists():
        raise ValueError("project is not initialized; run 007 init first")
    validate_marker(read_json(marker_path))
    instant = now or datetime.now(timezone.utc)
    if task_id is None:
        stamp = instant.strftime("%Y%m%dT%H%M%SZ")
        task_id = f"task-{stamp}-{uuid.uuid4().hex[:8]}"
    validate_task_id(task_id)
    task = {
        "schema": TASK_START_SCHEMA,
        "task_id": task_id,
        "started_at": instant.isoformat().replace("+00:00", "Z"),
    }
    if authority_file:
        task["authority"], task["authority_sha256"] = read_authority(authority_file)
    if acceptance_file:
        task["acceptance"], task["acceptance_sha256"] = read_acceptance(acceptance_file)
    validate_task_start(task)
    destination = marker_path.parent / "tasks" / f"{task_id}.task.json"
    write_json_no_replace(destination, task, "task start")
    return task


def validate_receipt(value):
    if not isinstance(value, dict) or value.get("schema") != RECEIPT_SCHEMA:
        raise ValueError(f"receipt schema must be {RECEIPT_SCHEMA}")
    if "authority_summary" in value:
        raise ValueError("authority_summary is computed by 007 record")
    if "authority_evidence" in value:
        raise ValueError("authority provenance is computed by 007")
    if any(key in value for key in ("acceptance_evidence", "acceptance_sha256", "acceptance_summary")):
        raise ValueError("acceptance provenance is computed by 007")
    validate_task_id(value.get("task_id"))
    if value.get("status") not in ("accepted", "blocked", "no-op"):
        raise ValueError("status must be accepted, blocked, or no-op")
    if value.get("task_class") is not None and value["task_class"] not in TASK_CLASSES:
        raise ValueError(f"task_class must be one of: {', '.join(sorted(TASK_CLASSES))}")
    cost = value.get("cost_usd")
    if (
        isinstance(cost, bool)
        or not isinstance(cost, (int, float))
        or not math.isfinite(cost)
        or cost < 0
    ):
        raise ValueError("cost_usd must be a non-negative measured number")
    source = value.get("cost_source")
    if not isinstance(source, str) or (
        source not in COST_SOURCES and not CUSTOM_COST_SOURCE.fullmatch(source)
    ):
        raise ValueError("cost_source must be documented or use custom:<name>")
    if value.get("cost_status") not in ("final", "provisional"):
        raise ValueError("cost_status must be final or provisional")
    required_strings = (
        "proof_required", "proof_reached", "first_pass", "corrective_lines",
        "escape_7d", "requested_provider", "requested_model", "requested_effort",
        "served_provider", "served_model", "served_effort", "uncertainty",
    )
    missing = [key for key in required_strings if not isinstance(value.get(key), str) or not value[key]]
    if missing:
        raise ValueError(f"missing receipt field(s): {', '.join(missing)}")
    if not isinstance(value.get("checks"), list) or not isinstance(value.get("delta"), dict):
        raise ValueError("checks must be a list and delta must be an object")
    repairs = value.get("repair_rounds")
    if repairs != "unmeasured" and (isinstance(repairs, bool) or not isinstance(repairs, int) or repairs < 0):
        raise ValueError("repair_rounds must be a non-negative integer or unmeasured")
    for key in ("tokens", "wall_s"):
        measured = value.get(key)
        if measured != "unmeasured" and (
            isinstance(measured, bool) or not isinstance(measured, (int, float)) or measured < 0
        ):
            raise ValueError(f"{key} must be a non-negative number or unmeasured")
    authority_hash = value.get("authority_sha256")
    events = value.get("boundary_events")
    if authority_hash is not None or events is not None:
        if not isinstance(authority_hash, str) or not SHA256.fullmatch(authority_hash):
            raise ValueError("authority_sha256 must be a lowercase SHA-256")
        if not isinstance(events, list):
            raise ValueError("boundary_events must be a list")
        for event in events:
            if (
                not isinstance(event, dict)
                or not isinstance(event.get("action"), str)
                or not TASK_ID.fullmatch(event["action"])
                or event.get("outcome") not in ("executed", "blocked")
            ):
                raise ValueError("boundary event requires action and executed|blocked outcome")
    return value


def write_controller_event(root, task, action, outcome, exit_code=None, now=None):
    validate_task_id(action)
    if outcome not in ("executed", "blocked"):
        raise ValueError("controller event outcome must be executed or blocked")
    instant = now or datetime.now(timezone.utc)
    event = {
        "schema": CONTROLLER_EVENT_SCHEMA,
        "task_id": task["task_id"],
        "action": action,
        "outcome": outcome,
        "authority_sha256": task["authority_sha256"],
        "observed_at": instant.isoformat().replace("+00:00", "Z"),
        "exit_code": exit_code,
    }
    write_json_no_replace(
        Path(root) / ".007" / "events" / f"{task['task_id']}.event.json",
        event,
        "controller event",
    )
    return event


def blocked_receipt(task, action):
    return {
        "schema": RECEIPT_SCHEMA,
        "task_id": task["task_id"],
        "status": "blocked",
        "proof_required": "authority",
        "proof_reached": "controller-blocked-before-execution",
        "checks": [{"command": f"007 authority {action}", "exit": 3}],
        "delta": {"files": 0, "added": 0, "deleted": 0, "dependencies": 0},
        "first_pass": "unmeasured",
        "repair_rounds": 0,
        "corrective_lines": "pending",
        "escape_7d": "pending",
        "requested_provider": "unmeasured",
        "requested_model": "unmeasured",
        "requested_effort": "unmeasured",
        "served_provider": "unmeasured",
        "served_model": "unmeasured",
        "served_effort": "unmeasured",
        "tokens": 0,
        "wall_s": 0,
        "cost_usd": 0,
        "cost_source": "local-compute",
        "cost_status": "final",
        "uncertainty": "subprocess not started",
    }


def bind_authority(receipt, task, controller_event=None):
    authority = task.get("authority") if task else None
    supplied = receipt.get("authority_sha256") is not None or receipt.get("boundary_events") is not None
    if authority is None:
        if supplied:
            raise ValueError("receipt claims authority but task start is not authority-bound")
        return receipt
    if controller_event is not None:
        if (
            controller_event.get("task_id") != task["task_id"]
            or controller_event.get("authority_sha256") != task.get("authority_sha256")
        ):
            raise ValueError("controller event does not match task start")
        receipt["authority_sha256"] = task["authority_sha256"]
        receipt["boundary_events"] = [{
            "action": controller_event["action"],
            "outcome": controller_event["outcome"],
        }]
        receipt["authority_evidence"] = "controlled"
    else:
        if receipt.get("authority_sha256") != task.get("authority_sha256"):
            raise ValueError("receipt authority_sha256 does not match task start")
        receipt["authority_evidence"] = "declared"
    events = receipt.get("boundary_events")
    if not isinstance(events, list):
        raise ValueError("authority-bound task requires boundary_events")
    allowed, denied = set(authority["allow"]), set(authority["deny"])
    summary = {
        "bound": True, "events": len(events), "allowed_executions": 0,
        "protected_blocks": 0, "friction_blocks": 0, "unclassified_blocks": 0,
    }
    for event in events:
        action, outcome = event["action"], event["outcome"]
        if outcome == "executed":
            if action not in allowed:
                raise ValueError(f"executed action outside bound authority: {action}")
            summary["allowed_executions"] += 1
        elif action in allowed:
            summary["friction_blocks"] += 1
        elif action in denied:
            summary["protected_blocks"] += 1
        else:
            summary["unclassified_blocks"] += 1
    receipt["authority_summary"] = summary
    return receipt


def run_acceptance(root, task):
    contract = task["acceptance"]
    timeout_s = contract.get("timeout_s", 900)
    checks = []
    for command in contract["commands"]:
        started = time.monotonic()
        timed_out = False
        try:
            completed = subprocess.run(
                command, cwd=root, capture_output=True, text=True, timeout=timeout_s,
            )
            exit_code = completed.returncode
            stdout, stderr = completed.stdout, completed.stderr
        except subprocess.TimeoutExpired as exc:
            exit_code, timed_out = 124, True
            stdout = exc.stdout or ""
            stderr = exc.stderr or ""
            if isinstance(stdout, bytes):
                stdout = stdout.decode(errors="replace")
            if isinstance(stderr, bytes):
                stderr = stderr.decode(errors="replace")
        checks.append({
            "command": command,
            "cwd": ".",
            "exit": exit_code,
            "duration_ms": round((time.monotonic() - started) * 1000),
            "stdout_sha256": hashlib.sha256(stdout.encode()).hexdigest(),
            "stderr_sha256": hashlib.sha256(stderr.encode()).hexdigest(),
            "timed_out": timed_out,
        })
    return checks


def bind_acceptance(receipt, task, checks=None):
    if "acceptance" not in task:
        if checks is not None:
            raise ValueError("acceptance results require a bound task contract")
        return receipt
    if checks is None:
        raise ValueError("acceptance-bound task requires controller-observed results")
    failed = sum(check["exit"] != 0 for check in checks)
    receipt["checks"] = checks
    receipt["acceptance_sha256"] = task["acceptance_sha256"]
    receipt["acceptance_evidence"] = "controlled"
    receipt["acceptance_summary"] = {"passed": len(checks) - failed, "failed": failed}
    if failed:
        receipt["status"] = "blocked"
        receipt["proof_reached"] = "acceptance-failed"
        receipt["first_pass"] = "no"
    return receipt


def record_receipt(repo, source, now=None, controller_event=None, acceptance_results=None):
    root = git_root(repo)
    marker_path = root / ".007" / "project.json"
    if not marker_path.exists():
        raise ValueError("project is not initialized; run 007 init first")
    marker = validate_marker(read_json(marker_path))
    if source == "-":
        value = json.load(sys.stdin)
    else:
        value = read_json(Path(source).expanduser())
    receipt = validate_receipt(value)
    task_path = marker_path.parent / "tasks" / f"{receipt['task_id']}.task.json"
    if not task_path.exists():
        raise ValueError("receipt requires a matching task start")
    task = validate_task_start(read_json(task_path))
    if task["task_id"] != receipt["task_id"]:
        raise ValueError("task start task_id does not match receipt")
    if controller_event is not None:
        event_path = marker_path.parent / "events" / f"{receipt['task_id']}.event.json"
        if not event_path.exists() or read_json(event_path) != controller_event:
            raise ValueError("controlled provenance requires the persisted controller event")
    receipt = bind_authority(receipt, task, controller_event)
    receipt = bind_acceptance(receipt, task, acceptance_results)
    if "completed_at" not in receipt:
        instant = now or datetime.now(timezone.utc)
        receipt["completed_at"] = instant.isoformat().replace("+00:00", "Z")
    elif not isinstance(receipt["completed_at"], str) or not receipt["completed_at"]:
        raise ValueError("completed_at must be a timestamp string")
    destination = receipt_directory(marker_path, marker) / f"{receipt['task_id']}.receipt.json"
    write_json_no_replace(destination, receipt)
    return destination


def run_task(repo, task_id, receipt, command, authority_file=None, action=None, acceptance_file=None):
    root = git_root(repo)
    command = command[1:] if command[:1] == ["--"] else command
    if not command:
        raise ValueError("run requires a command after --")
    if authority_file and not action:
        raise ValueError("authority-bound run requires --action")
    if action and not authority_file:
        raise ValueError("--action requires --authority-file")
    if action:
        validate_task_id(action)
    receipt_path = Path(receipt).expanduser()
    if not receipt_path.is_absolute():
        receipt_path = root / receipt_path
    receipt_path = receipt_path.resolve()
    if receipt_path.exists():
        raise ValueError(f"terminal receipt already exists: {receipt_path}")

    task = begin_task(
        root, task_id, authority_file=authority_file, acceptance_file=acceptance_file,
    )
    if action and action not in set(task["authority"]["allow"]):
        event = write_controller_event(root, task, action, "blocked")
        write_json_atomic(receipt_path, blocked_receipt(task, action))
        return 3, record_receipt(root, receipt_path, controller_event=event)
    environment = {
        **os.environ,
        "FRAMEWORK_007_TASK_ID": task["task_id"],
        "FRAMEWORK_007_RECEIPT_PATH": str(receipt_path),
        "FRAMEWORK_007_REPO": str(root),
    }
    if task.get("authority_sha256"):
        environment["FRAMEWORK_007_AUTHORITY_SHA256"] = task["authority_sha256"]
    completed = subprocess.run(command, cwd=root, env=environment)
    event = (
        write_controller_event(root, task, action, "executed", completed.returncode)
        if action else None
    )
    if completed.returncode:
        return completed.returncode, None
    if not receipt_path.is_file():
        raise ValueError(f"command did not produce terminal receipt: {receipt_path}")
    receipt_value = validate_receipt(read_json(receipt_path))
    if receipt_value["task_id"] != task["task_id"]:
        raise ValueError("terminal receipt task_id does not match the observed task")
    checks = run_acceptance(root, task) if acceptance_file else None
    destination = record_receipt(
        root, receipt_path, controller_event=event, acceptance_results=checks,
    )
    return (4 if checks and any(check["exit"] != 0 for check in checks) else 0), destination


def parser():
    result = argparse.ArgumentParser(description="007 Framework local tooling")
    commands = result.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init", help="register a Git project for 007 telemetry")
    init.add_argument("--repo", default=".")
    init.add_argument("--registry", type=Path, default=default_registry_path())
    begin = commands.add_parser("begin", help="observe the start of one task")
    begin.add_argument("--repo", default=".")
    begin.add_argument("--task-id")
    begin.add_argument("--authority-file", type=Path)
    record = commands.add_parser("record", help="validate and persist one terminal task receipt")
    record.add_argument("--repo", default=".")
    record.add_argument("--file", required=True, help="receipt JSON path, or - for stdin")
    run = commands.add_parser("run", help="observe a command and require its terminal receipt")
    run.add_argument("--repo", default=".")
    run.add_argument("--task-id")
    run.add_argument("--receipt", required=True)
    run.add_argument("--authority-file", type=Path)
    run.add_argument("--action")
    run.add_argument("--acceptance-file", type=Path)
    run.add_argument("argv", nargs=argparse.REMAINDER, help="command after --")
    route = commands.add_parser("route", help="select the cheapest measured eligible executor")
    route.add_argument("--task-class", required=True, choices=sorted(TASK_CLASSES))
    route.add_argument("--config", type=Path, default=default_route_config_path())
    route.add_argument("--repo", default=".")
    route.add_argument("--format", choices=("json", "text"), default="text")
    unregister = commands.add_parser("unregister", help="remove a stale project from the local registry")
    unregister.add_argument("--project", required=True, help="registered project path or project ID")
    unregister.add_argument("--registry", type=Path, default=default_registry_path())
    dashboard = commands.add_parser("dashboard", help="start the local multi-project dashboard")
    dashboard.add_argument("--host", default="127.0.0.1")
    dashboard.add_argument("--port", type=int, default=7007)
    dashboard.add_argument("--registry", type=Path, default=default_registry_path())
    dashboard.add_argument("--no-open", action="store_true")
    return result


def run_dashboard(host, port, registry, open_browser=True):
    import dashboard

    static_dir = Path(__file__).resolve().parents[1] / "dashboard"
    server = dashboard.create_server(host, port, registry, static_dir)
    url = f"http://{host}:{server.server_port}"
    print(f"007 dashboard: {url}")
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == "init":
            entry = init_project(args.repo, args.registry)
            print(f"registered {entry['name']} ({entry['path']})")
            print(f"receipts: {Path(entry['path']) / '.007' / 'receipts'}")
            return 0
        if args.command == "begin":
            task = begin_task(args.repo, args.task_id, authority_file=args.authority_file)
            print(f"started: {task['task_id']}")
            return 0
        if args.command == "record":
            destination = record_receipt(args.repo, args.file)
            print(f"recorded: {destination}")
            return 0
        if args.command == "run":
            status, destination = run_task(
                args.repo, args.task_id, args.receipt, args.argv,
                args.authority_file, args.action, args.acceptance_file,
            )
            if destination:
                print(f"recorded: {destination}")
            return status
        if args.command == "route":
            config = validate_route_config(read_json(args.config.expanduser()))
            decision = select_route(
                config["candidates"], load_route_receipts(args.repo), args.task_class,
            )
            decision["evidence_scope"] = "repository-local"
            if args.format == "json":
                print(json.dumps(decision, indent=2, sort_keys=True))
            elif decision["selected"]:
                selected = decision["selected"]
                print(f"{selected['id']}: {selected['provider']}/{selected['model']}@{selected['effort']} ({decision['strategy']}) [repository-local]")
            else:
                print("no available route", file=sys.stderr)
            return 0 if decision["selected"] else 3
        if args.command == "unregister":
            entry = unregister_project(args.project, args.registry)
            print(f"unregistered: {entry['name']} ({entry['path']})")
            return 0
        if args.command == "dashboard":
            return run_dashboard(args.host, args.port, args.registry, not args.no_open)
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    sys.exit(main())
